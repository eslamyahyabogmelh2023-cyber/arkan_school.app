# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════╗
║        ARKAN SCHOOL  ·  منظومة أركان V37 PRO        ║
║  النسخة الاحترافية الكاملة مع جميع الميزات المتطورة ║
║           تطوير: تدفق الأنظمة  ·  Tadafuq Systems    ║
╚══════════════════════════════════════════════════════╝
تشغيل: python arkan_school_v37.py
متطلبات: pip install customtkinter pillow reportlab openpyxl
"""

import os, sys, sqlite3, secrets, shutil, hashlib, csv, re, webbrowser, urllib.parse
from datetime import date, datetime

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:
    import customtkinter as ctk
except ImportError:
    raise SystemExit("pip install customtkinter")

try:
    from PIL import Image, ImageTk, ImageFilter
except ImportError:
    raise SystemExit("pip install pillow")

# مسار البرنامج — دائماً في نفس مجلد الملف
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

DB_NAME    = os.path.join(_SCRIPT_DIR, "arkan_school.db")
BACKUP_DIR = os.path.join(_SCRIPT_DIR, "BACKUPS")
LOGO_PATH  = os.path.join(_SCRIPT_DIR, "arkan_logo.jpg")

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# ══════════════════════════════════════════
#  اللون والخطوط — وضع فاتح احترافي
# ══════════════════════════════════════════
C = {
    "bg":       "#F0F4F8",   # خلفية عامة رمادي فاتح
    "sidebar":  "#1A2744",   # شريط جانبي كحلي داكن (يبقى داكناً للتباين)
    "sidebar2": "#243460",   # hover في السايدبار
    "card":     "#FFFFFF",   # بطاقات بيضاء
    "card2":    "#F8FAFC",   # حقول الإدخال
    "border":   "#CBD5E1",   # حدود رمادية خفيفة
    "gold":     "#B8860B",   # ذهبي داكن يظهر على الفاتح
    "gold2":    "#DAA520",   # ذهبي متوسط
    "gold_dim": "#F5DEB3",   # ذهبي شاحب للخلفيات
    "teal":     "#0D9488",   # أخضر مزرق
    "teal2":    "#0F766E",
    "red":      "#DC2626",
    "red2":     "#B91C1C",
    "green":    "#16A34A",
    "text":     "#1E293B",   # نص داكن على خلفية فاتحة
    "muted":    "#64748B",   # نص ثانوي رمادي
    "white":    "#FFFFFF",
    "row_odd":  "#FFFFFF",
    "row_even": "#F8FAFC",
    "sel":      "#DBEAFE",   # أزرق فاتح عند التحديد
    "topbar":   "#1A2744",   # شريط علوي كحلي
    "orange":   "#D97706",
}

F = {
    "title": ("Tahoma", 26, "bold"),
    "head":  ("Tahoma", 18, "bold"),
    "sub":   ("Tahoma", 12),
    "btn":   ("Tahoma", 12, "bold"),
    "entry": ("Tahoma", 12),
    "tree":  ("Tahoma", 11),
    "treeh": ("Tahoma", 11, "bold"),
    "cardv": ("Tahoma", 24, "bold"),
    "cardl": ("Tahoma", 11),
    "small": ("Tahoma", 10),
    "big":   ("Tahoma", 30, "bold"),
}

# ══════════════════════════════════════════
#  صلاحيات
# ══════════════════════════════════════════
ROLE_LABELS = {
    "admin":      "مدير النظام",
    "registrar":  "موظف التسجيل",
    "accountant": "المحاسب",
    "teacher":    "المعلم",
    "viewer":     "مشاهدة فقط",
}
ROLE_PERMS = {
    "admin":      {"dashboard","classes","subjects","students","teachers","assign",
                   "attendance","att_log","teacher_att","grades","notes","payments",
                   "reports","backup","admin_tools","export"},
    "registrar":  {"dashboard","classes","subjects","students","attendance",
                   "att_log","teacher_att","reports","notes","export"},
    "accountant": {"dashboard","payments","reports","export"},
    "teacher":    {"dashboard","attendance","att_log","grades","reports","notes"},
    "viewer":     {"dashboard","reports"},
}

# ══════════════════════════════════════════
#  قاعدة البيانات
# ══════════════════════════════════════════
def connect():
    return sqlite3.connect(DB_NAME)

def init_db():
    con = connect(); cur = con.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS classes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_name TEXT NOT NULL,
        section TEXT NOT NULL,
        academic_year TEXT NOT NULL)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        grade TEXT,
        parent_phone TEXT,
        parent_code TEXT,
        total_fees REAL DEFAULT 0,
        paid_fees REAL DEFAULT 0,
        class_id INTEGER)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS teachers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        subject TEXT,
        phone TEXT,
        salary REAL DEFAULT 0)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS subjects(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_name TEXT NOT NULL,
        class_id INTEGER)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS teacher_assignments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        teacher_id INTEGER,
        class_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        UNIQUE(username,class_id,subject_id))""")

    cur.execute("""CREATE TABLE IF NOT EXISTS grades(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        work_score REAL DEFAULT 0,
        mid_score REAL DEFAULT 0,
        final_score REAL DEFAULT 0,
        total_score REAL DEFAULT 0,
        grade_text TEXT,
        exam_date TEXT,
        author TEXT)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        pay_date TEXT NOT NULL,
        note TEXT)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS attendance(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        person_type TEXT NOT NULL,
        person_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        status TEXT NOT NULL,
        day TEXT NOT NULL)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS student_notes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        note_text TEXT NOT NULL,
        note_date TEXT NOT NULL,
        author TEXT)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS notifications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        notify_date TEXT NOT NULL,
        is_read INTEGER DEFAULT 0)""")

    # safe ALTER
    for tbl, col in [
        ("students","class_id INTEGER"),
        ("students","parent_code TEXT"),
        ("grades","author TEXT"),
    ]:
        try: cur.execute(f"ALTER TABLE {tbl} ADD COLUMN {col}")
        except: pass

    # مستخدمون افتراضيون
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        for u,p,r in [
            ("admin","1234","admin"),
            ("teacher1","1234","teacher"),
            ("account1","1234","accountant"),
            ("office1","1234","registrar"),
        ]:
            cur.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",(u,p,r))

    # توافق قواعد البيانات القديمة
    try:
        cur.execute("PRAGMA table_info(classes)")
        cols = [r[1] for r in cur.fetchall()]
        if "class_name" not in cols:
            try:
                cur.execute("ALTER TABLE classes ADD COLUMN class_name TEXT")
            except:
                pass
            try:
                cur.execute("UPDATE classes SET class_name=name WHERE class_name IS NULL OR class_name=''")
            except:
                pass
    except:
        pass

    # فصول افتراضية
    cur.execute("SELECT COUNT(*) FROM classes")
    if cur.fetchone()[0] == 0:
        default_classes = [
            ("KG1","أ","2026-2027"),("KG2","أ","2026-2027"),
            ("الأول ابتدائي","أ","2026-2027"),("الثاني ابتدائي","أ","2026-2027"),
            ("الثالث ابتدائي","أ","2026-2027"),("الرابع ابتدائي","أ","2026-2027"),
            ("الخامس ابتدائي","أ","2026-2027"),("السادس ابتدائي","أ","2026-2027"),
            ("الأول إعدادي","أ","2026-2027"),("الثاني إعدادي","أ","2026-2027"),
            ("الثالث إعدادي","أ","2026-2027"),
        ]
        cur.executemany("INSERT INTO classes(class_name,section,academic_year) VALUES(?,?,?)", default_classes)

    # مواد افتراضية
    cur.execute("SELECT COUNT(*) FROM subjects")
    if cur.fetchone()[0] == 0:
        cur.execute("SELECT id FROM classes ORDER BY id")
        cids = [r[0] for r in cur.fetchall()]
        subs = ["الرياضيات","اللغة العربية","العلوم","اللغة الإنجليزية","التربية الإسلامية"]
        for cid in cids:
            for s in subs:
                cur.execute("INSERT INTO subjects(subject_name,class_id) VALUES(?,?)",(s,cid))

    # كود ولي الأمر لكل طالب
    cur.execute("SELECT id FROM students WHERE parent_code IS NULL OR parent_code=''")
    for (sid,) in cur.fetchall():
        cur.execute("UPDATE students SET parent_code=? WHERE id=?",
                    (f"ARK-{1000+int(sid)}", sid))

    # تحديث grade من class
    try:
        cur.execute("""UPDATE students
            SET grade=(SELECT class_name||' '||section FROM classes WHERE id=students.class_id)
            WHERE class_id IS NOT NULL""")
    except: pass

    con.commit(); con.close()

# ══════════════════════════════════════════
#  تشفير كلمات المرور
# ══════════════════════════════════════════
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    if len(hashed) == 64:
        return hash_password(password) == hashed
    return password == hashed  # نص قديم — سيُشفَّر عند أول دخول

def migrate_plain_passwords():
    """تحويل كلمات المرور القديمة غير المشفرة إلى مشفرة تلقائياً"""
    con = connect(); cur = con.cursor()
    cur.execute("SELECT id, password FROM users")
    for uid, pwd in cur.fetchall():
        if len(pwd) != 64:
            cur.execute("UPDATE users SET password=? WHERE id=?", (hash_password(pwd), uid))
    con.commit(); con.close()

# ══════════════════════════════════════════
#  التحقق من صحة التاريخ
# ══════════════════════════════════════════
def validate_date(date_str: str) -> bool:
    try:
        datetime.strptime(date_str.strip(), "%Y-%m-%d")
        return True
    except:
        return False

# ══════════════════════════════════════════
#  مساعدات
# ══════════════════════════════════════════
def normalize_phone(phone):
    phone = str(phone or "").strip().replace(" ","").replace("-","")
    if phone.startswith("+218"): phone = "0" + phone[4:]
    elif phone.startswith("218"): phone = "0" + phone[3:]
    return phone

def grade_label(total):
    if total >= 85: return "ممتاز"
    if total >= 75: return "جيد جداً"
    if total >= 65: return "جيد"
    if total >= 50: return "مقبول"
    return "راسب"

def push_notification(student_id, title, message):
    try:
        con = connect(); cur = con.cursor()
        cur.execute("INSERT INTO notifications(student_id,title,message,notify_date,is_read) VALUES(?,?,?,?,0)",
                    (student_id, title, message, str(date.today())))
        con.commit(); con.close()
    except: pass

_toast_win = None

def show_toast(root, message, color="#0D9488", duration=2500):
    global _toast_win
    try:
        if _toast_win and _toast_win.winfo_exists():
            _toast_win.destroy()
    except: pass
    try:
        w = tk.Toplevel(root)
        w.overrideredirect(True)
        w.attributes("-topmost", True)
        try: w.attributes("-alpha", 0.92)
        except: pass
        sw = root.winfo_screenwidth()
        w.geometry(f"380x52+{sw//2-190}+18")
        w.configure(bg=color)
        tk.Label(w, text=message, bg=color, fg="white",
                 font=("Tahoma", 12, "bold"), padx=20, pady=14).pack(fill="both", expand=True)
        _toast_win = w
        w.after(duration, lambda: w.destroy() if w.winfo_exists() else None)
    except: pass

def backup_db():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(BACKUP_DIR, f"arkan_backup_{ts}.db")
    shutil.copy2(DB_NAME, dst)
    return dst

def restore_db(path):
    shutil.copy2(path, DB_NAME)

# ══════════════════════════════════════════
#  PDF  (اختياري إذا كان reportlab موجود)
# ══════════════════════════════════════════
PDF_OK = False
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    PDF_OK = True
except: pass

def export_grades_pdf(student_name, grade_name, grades_data, save_path):
    if not PDF_OK:
        messagebox.showwarning("تنبيه", "قم بتثبيت: pip install reportlab")
        return
    doc = SimpleDocTemplate(save_path, pagesize=A4,
                            rightMargin=2*cm, leftMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    story = []
    title_style = ParagraphStyle('t', fontName='Helvetica-Bold', fontSize=16,
                                 alignment=1, spaceAfter=6)
    sub_style   = ParagraphStyle('s', fontName='Helvetica', fontSize=11,
                                 alignment=1, spaceAfter=12)
    story.append(Paragraph("ARKAN SCHOOL", title_style))
    story.append(Paragraph(f"Student: {student_name}  |  Class: {grade_name}", sub_style))
    story.append(Spacer(1, 0.4*cm))

    header = ["Subject","Work(20)","Mid(30)","Final(50)","Total","Grade"]
    data   = [header]
    for row in grades_data:
        data.append(list(row))
    t = Table(data, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0), colors.HexColor("#0D1B2A")),
        ('TEXTCOLOR',(0,0),(-1,0), colors.HexColor("#C8A84B")),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('FONTSIZE',(0,0),(-1,-1),10),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, colors.HexColor("#F0F4F8")]),
        ('GRID',(0,0),(-1,-1),0.5,colors.grey),
        ('TOPPADDING',(0,0),(-1,-1),6),
        ('BOTTOMPADDING',(0,0),(-1,-1),6),
    ]))
    story.append(t)
    story.append(Spacer(1, 1*cm))
    story.append(Paragraph("Signature: ___________________", sub_style))
    doc.build(story)

# ══════════════════════════════════════════
#  التطبيق الرئيسي
# ══════════════════════════════════════════
class ArkanV30(ctk.CTk):
    def __init__(self):
        super().__init__()
        try: self.tk.call("encoding","system","utf-8")
        except: pass

        self.title("ARKAN SCHOOL  ·  منظومة أركان V37 PRO  ·  تدفق الأنظمة")
        self.geometry("1440x880")
        self.minsize(1200, 720)
        self.configure(fg_color=C["bg"])
        try: self.state("zoomed")
        except: pass

        self._logo_pil = None
        self._logo_img = None
        self._load_logo()

        self.current_user_id   = None
        self.current_username  = None
        self.current_role      = None

        self.show_login()

    # ── LOGO ──
    def _load_logo(self):
        if os.path.exists(LOGO_PATH):
            try:
                img = Image.open(LOGO_PATH).convert("RGBA")
                self._logo_pil = img
                self._logo_img = ctk.CTkImage(light_image=img, dark_image=img, size=(110,110))
                print(f"✅ تم تحميل الشعار: {LOGO_PATH}")
            except Exception as e:
                print(f"❌ خطأ في تحميل الشعار: {e}")
        else:
            print(f"⚠️  ملف الشعار غير موجود في: {LOGO_PATH}")
            print(f"    ضع ملف arkan_logo.jpg في: {_SCRIPT_DIR}")

    def _logo_sized(self, w, h):
        if not self._logo_pil: return None
        return ctk.CTkImage(light_image=self._logo_pil, dark_image=self._logo_pil, size=(w,h))

    def _make_bg_photo(self, w, h):
        if not self._logo_pil: return None
        try:
            logo = self._logo_pil.copy().convert("RGBA")
            sc = int(h*0.55)
            logo = logo.resize((sc,sc), Image.LANCZOS)
            logo = logo.filter(ImageFilter.GaussianBlur(radius=14))
            r,g,b,a = logo.split()
            a = a.point(lambda x: int(x*0.10))
            logo = Image.merge("RGBA",(r,g,b,a))
            bg = Image.new("RGBA",(w,h),(232,238,245,255))
            bg.paste(logo,((w-sc)//2,(h-sc)//2),logo)
            return ImageTk.PhotoImage(bg.convert("RGB"))
        except: return None

    # ── CLEAR ──
    def clear(self):
        for w in self.winfo_children(): w.destroy()

    def has_perm(self, key):
        if self.current_role == "admin": return True
        return key in ROLE_PERMS.get(self.current_role or "viewer", set())

    def open_page(self, key, fn):
        if not self.has_perm(key):
            messagebox.showwarning("صلاحيات","ليس لديك صلاحية لهذه الشاشة"); return
        fn()

    # ══════════════════════════════════
    #  شاشة الدخول
    # ══════════════════════════════════
    def show_login(self):
        self.current_user_id = self.current_username = self.current_role = None
        self.clear()
        self.update_idletasks()

        canvas = tk.Canvas(self, bd=0, highlightthickness=0, bg="#E8EEF5")
        canvas.place(x=0,y=0,relwidth=1,relheight=1)

        def _draw(e=None):
            cw,ch = canvas.winfo_width(), canvas.winfo_height()
            if cw < 10: return
            ph = self._make_bg_photo(cw,ch)
            if ph:
                self._bgph = ph
                canvas.delete("bg")
                canvas.create_image(0,0,anchor="nw",image=ph,tags="bg")
                canvas.tag_lower("bg")
        canvas.bind("<Configure>", _draw)
        self.after(120, _draw)

        card = ctk.CTkFrame(self, width=500, height=660,
                            fg_color=C["white"], corner_radius=36,
                            border_width=2, border_color=C["gold"])
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        ctk.CTkFrame(card, height=7, fg_color=C["gold"], corner_radius=0).pack(fill="x")

        if self._logo_img:
            ctk.CTkLabel(card, image=self._logo_img, text="").pack(pady=(28,4))

        ctk.CTkLabel(card, text="ARKAN SCHOOL",
                     font=("Tahoma",34,"bold"), text_color=C["gold"]).pack()
        ctk.CTkLabel(card, text="منظومة أركان المدرسية  ·  V35 PRO",
                     font=("Tahoma",13), text_color=C["muted"]).pack(pady=(2,2))
        ctk.CTkLabel(card, text="⚙️  تدفق الأنظمة  ·  Tadafuq Systems",
                     font=("Tahoma",10), text_color=C["teal"]).pack(pady=(0,4))
        ctk.CTkFrame(card, height=1, width=320, fg_color=C["border"]).pack(pady=(4,18))

        self._u = ctk.CTkEntry(card, width=370, height=50,
            placeholder_text="👤  اسم المستخدم", justify="center",
            font=F["entry"], fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=14)
        self._u.pack(pady=6)

        self._p = ctk.CTkEntry(card, width=370, height=50,
            placeholder_text="🔒  كلمة المرور", show="*", justify="center",
            font=F["entry"], fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=14)
        self._p.pack(pady=6)
        self._p.bind("<Return>", lambda e: self._login())

        ctk.CTkButton(card, text="تسجيل الدخول", width=370, height=52,
            fg_color=C["gold"], hover_color=C["gold2"],
            text_color=C["white"], font=("Tahoma",14,"bold"),
            corner_radius=14, command=self._login).pack(pady=(18,6))

        ctk.CTkLabel(card, text="admin · teacher1 · account1  /  1234",
                     font=F["small"], text_color=C["muted"]).pack(pady=2)
        ctk.CTkFrame(card, height=1, width=320, fg_color=C["border"]).pack(pady=(8,6))

        ctk.CTkButton(card, text="🔑  دخول ولي الأمر", width=370, height=46,
            fg_color=C["card2"], hover_color=C["gold_dim"],
            text_color=C["teal"], font=("Tahoma",13,"bold"),
            border_width=1, border_color=C["teal"],
            corner_radius=14, command=self.show_parent_login).pack(pady=(0,20))

    def _login(self):
        u = self._u.get().strip(); p = self._p.get().strip()
        con = connect(); cur = con.cursor()
        cur.execute("SELECT id,username,role,password FROM users WHERE username=?",(u,))
        row = cur.fetchone()
        if not row or not verify_password(p, row[3]):
            con.close()
            messagebox.showerror("خطأ","بيانات الدخول غير صحيحة"); return
        # ترقية كلمة المرور إذا كانت نصاً عادياً
        if len(row[3]) != 64:
            cur.execute("UPDATE users SET password=? WHERE id=?", (hash_password(p), row[0]))
            con.commit()
        con.close()
        self.current_user_id = row[0]
        self.current_username = row[1]
        self.current_role = row[2] or "viewer"
        self.show_main()

    # ══════════════════════════════════
    #  بوابة ولي الأمر — دخول برقم الهاتف فقط
    # ══════════════════════════════════
    def show_parent_login(self):
        self.clear()
        outer = ctk.CTkFrame(self, fg_color=C["bg"]); outer.pack(fill="both",expand=True)

        card = ctk.CTkFrame(outer, width=500, height=460,
                            fg_color=C["white"], corner_radius=32,
                            border_width=2, border_color=C["teal"])
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        ctk.CTkFrame(card, height=6, fg_color=C["teal"], corner_radius=0).pack(fill="x")

        if self._logo_sized(60,60):
            ctk.CTkLabel(card, image=self._logo_sized(60,60), text="").pack(pady=(24,4))

        ctk.CTkLabel(card, text="بوابة ولي الأمر",
                     font=("Tahoma",26,"bold"), text_color=C["teal"]).pack(pady=(0,4))
        ctk.CTkLabel(card, text="أدخل رقم هاتفك المسجّل في المدرسة",
                     font=F["sub"], text_color=C["muted"]).pack(pady=(0,24))

        self._pp = ctk.CTkEntry(card, width=370, height=50,
            placeholder_text="📞  رقم الهاتف", justify="center",
            font=F["entry"], fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=14)
        self._pp.pack(pady=6)
        self._pp.bind("<Return>", lambda e: self._parent_login())

        ctk.CTkButton(card, text="دخول", width=370, height=50,
            fg_color=C["teal"], hover_color=C["teal2"],
            text_color=C["white"], font=("Tahoma",14,"bold"),
            corner_radius=14, command=self._parent_login).pack(pady=(16,8))

        ctk.CTkButton(card, text="رجوع", width=370, height=42,
            fg_color=C["card2"], hover_color=C["border"],
            text_color=C["muted"], font=F["btn"],
            corner_radius=14, command=self.show_login).pack(pady=4)

    def _parent_login(self):
        phone = normalize_phone(self._pp.get())
        if not phone:
            messagebox.showwarning("تنبيه","اكتب رقم الهاتف"); return
        con = connect(); cur = con.cursor()
        cur.execute("""SELECT id,name,grade,parent_phone,parent_code,total_fees,paid_fees
                       FROM students WHERE parent_phone IS NOT NULL ORDER BY id""")
        rows = [r for r in cur.fetchall() if normalize_phone(r[3])==phone]
        con.close()
        if not rows:
            messagebox.showerror("خطأ","رقم الهاتف غير مسجّل في المدرسة"); return
        self.show_parent_dashboard(rows)

    def show_parent_dashboard(self, students):
        self.clear()
        page = ctk.CTkFrame(self, fg_color=C["bg"]); page.pack(fill="both",expand=True)

        # header
        hdr = ctk.CTkFrame(page, fg_color=C["topbar"], corner_radius=0, height=66)
        hdr.pack(fill="x"); hdr.pack_propagate(False)

        brand = ctk.CTkFrame(hdr, fg_color="transparent"); brand.pack(side="right", padx=18)
        if self._logo_sized(38,38):
            ctk.CTkLabel(brand, image=self._logo_sized(38,38), text="").pack(side="right",padx=(0,8))
        ctk.CTkLabel(brand, text="ARKAN SCHOOL  ·  بوابة ولي الأمر",
                     font=("Tahoma",16,"bold"), text_color=C["gold"]).pack(side="right")

        ctk.CTkButton(hdr, text="خروج 🚪", command=self.show_login,
            fg_color=C["card2"], hover_color=C["red2"],
            text_color=C["muted"], font=F["btn"],
            width=90, height=36, corner_radius=10).pack(side="left",padx=16,pady=14)

        ctk.CTkButton(hdr, text="📤  تصدير CSV", command=lambda: self._export_parent_csv(students),
            fg_color=C["teal"], hover_color=C["teal2"],
            text_color=C["white"], font=F["btn"],
            width=120, height=36, corner_radius=10).pack(side="left",padx=4,pady=14)

        body = ctk.CTkScrollableFrame(page, fg_color=C["bg"])
        body.pack(fill="both",expand=True,padx=28,pady=20)

        if len(students) > 1:
            ctk.CTkLabel(body, text="اختر الطالب:", font=F["head"],
                         text_color=C["gold"]).pack(anchor="e", pady=(0,8))
            for s in students:
                ctk.CTkButton(body, text=f"👨‍🎓  {s[1]}  —  {s[2]}",
                    fg_color=C["card"], hover_color=C["teal"],
                    text_color=C["text"], font=("Tahoma",14,"bold"),
                    height=50, corner_radius=14,
                    command=lambda st=s: self._show_one_student(body, st)
                ).pack(fill="x", pady=4)
        else:
            self._show_one_student(body, students[0])

    def _show_one_student(self, body, student):
        for w in body.winfo_children(): w.destroy()
        sid, name, grade, _, parent_code, total_fees, paid_fees = student
        total_fees = float(total_fees or 0)
        paid_fees  = float(paid_fees or 0)

        info = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=20,
                            border_width=1, border_color=C["gold"])
        info.pack(fill="x", pady=(0,14))
        ctk.CTkFrame(info, height=4, fg_color=C["gold"]).pack(fill="x")
        ctk.CTkLabel(info, text=f"👨‍🎓  {name}", font=("Tahoma",20,"bold"),
                     text_color=C["gold"]).pack(anchor="e",padx=24,pady=(14,4))
        ctk.CTkLabel(info, text=f"الفصل: {grade}",
                     font=F["sub"], text_color=C["muted"]).pack(anchor="e",padx=24,pady=(0,14))

        fr = ctk.CTkFrame(body, fg_color=C["bg"]); fr.pack(fill="x")
        for lbl,val,icon,acc in [
            ("إجمالي الرسوم", f"{total_fees:.2f} د.ل", "💰", C["gold"]),
            ("المدفوع",       f"{paid_fees:.2f} د.ل",  "✅", C["teal"]),
            ("المتبقي",       f"{total_fees-paid_fees:.2f} د.ل", "⚠️", C["red"]),
        ]:
            self._stat_card(fr, lbl, val, icon, acc)

        con = connect(); cur = con.cursor()
        cur.execute("SELECT status,COUNT(*) FROM attendance WHERE person_type='طالب' AND person_id=? GROUP BY status",(sid,))
        att = dict(cur.fetchall())
        cur.execute("""SELECT subjects.subject_name,grades.work_score,grades.mid_score,
                       grades.final_score,grades.total_score,grades.grade_text,grades.exam_date
                       FROM grades JOIN subjects ON grades.subject_id=subjects.id
                       WHERE grades.student_id=? ORDER BY grades.exam_date DESC""",(sid,))
        gr = cur.fetchall()
        cur.execute("SELECT note_date,note_text,IFNULL(author,'') FROM student_notes WHERE student_id=? ORDER BY id DESC",(sid,))
        notes = cur.fetchall()
        cur.execute("SELECT notify_date,title,message FROM notifications WHERE student_id=? AND is_read=0 ORDER BY id DESC LIMIT 20",(sid,))
        notifs = cur.fetchall()
        con.close()

        # حضور
        ac = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=18,
                          border_width=1, border_color=C["border"])
        ac.pack(fill="x", pady=10)
        ctk.CTkLabel(ac, text="📋  الحضور والغياب", font=F["head"],
                     text_color=C["text"]).pack(anchor="e",padx=22,pady=(14,4))
        ctk.CTkLabel(ac,
            text=f"حاضر: {att.get('حاضر',0)}    |    غائب: {att.get('غائب',0)}    |    متأخر: {att.get('متأخر',0)}",
            font=F["sub"], text_color=C["muted"]).pack(anchor="e",padx=22,pady=(0,14))

        # درجات
        gc = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=18,
                          border_width=1, border_color=C["border"])
        gc.pack(fill="both", pady=10)
        ctk.CTkLabel(gc, text="📊  الدرجات", font=F["head"],
                     text_color=C["text"]).pack(anchor="e",padx=22,pady=(14,8))
        if not gr:
            ctk.CTkLabel(gc, text="لا توجد درجات مسجلة حتى الآن",
                         font=F["sub"], text_color=C["muted"]).pack(anchor="e",padx=22,pady=10)
        else:
            t = self._styled_tree(gc, ["المادة","أعمال","نصف","نهائي","المجموع","التقدير","التاريخ"], height=6)
            for row in gr: t.insert("","end",values=row)

        # ملاحظات
        nc = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=18,
                          border_width=1, border_color=C["border"])
        nc.pack(fill="both", pady=10)
        ctk.CTkLabel(nc, text="📝  ملاحظات المدرسة", font=F["head"],
                     text_color=C["text"]).pack(anchor="e",padx=22,pady=(14,8))
        if not notes:
            ctk.CTkLabel(nc, text="لا توجد ملاحظات", font=F["sub"],
                         text_color=C["muted"]).pack(anchor="e",padx=22,pady=10)
        else:
            nt = self._styled_tree(nc, ["التاريخ","الملاحظة","الكاتب"], height=4)
            for row in notes: nt.insert("","end",values=row)

        # إشعارات
        ic = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=18,
                          border_width=1, border_color=C["border"])
        ic.pack(fill="both", pady=10)
        ctk.CTkLabel(ic, text="🔔  الإشعارات الجديدة", font=F["head"],
                     text_color=C["text"]).pack(anchor="e",padx=22,pady=(14,8))
        if not notifs:
            ctk.CTkLabel(ic, text="لا توجد إشعارات جديدة", font=F["sub"],
                         text_color=C["muted"]).pack(anchor="e",padx=22,pady=10)
        else:
            it = self._styled_tree(ic, ["التاريخ","العنوان","الرسالة"], height=4)
            for row in notifs: it.insert("","end",values=row)

    def _export_parent_csv(self, students):
        """تصدير ملخص الطالب لولي الأمر كـ CSV"""
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV","*.csv")],
            initialfile=f"ملخص_الطالب_{students[0][1]}.csv")
        if not path: return
        try:
            sid = students[0][0]
            con = connect(); cur = con.cursor()
            cur.execute("""SELECT sub.subject_name,g.work_score,g.mid_score,
                           g.final_score,g.total_score,g.grade_text FROM grades g
                           JOIN subjects sub ON g.subject_id=sub.id
                           WHERE g.student_id=?""",(sid,))
            grades = cur.fetchall()
            cur.execute("SELECT status,COUNT(*) FROM attendance WHERE person_type='طالب' AND person_id=? GROUP BY status",(sid,))
            att = dict(cur.fetchall())
            con.close()
            with open(path,"w",newline="",encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["الطالب","الفصل","إجمالي الرسوم","المدفوع","المتبقي"])
                for s in students:
                    w.writerow([s[1],s[2],s[5],s[6],float(s[5] or 0)-float(s[6] or 0)])
                w.writerow([])
                w.writerow(["الحضور","غائب","متأخر"])
                w.writerow([att.get("حاضر",0),att.get("غائب",0),att.get("متأخر",0)])
                w.writerow([])
                w.writerow(["المادة","أعمال","نصف","نهائي","المجموع","التقدير"])
                w.writerows(grades)
            messagebox.showinfo("تم",f"تم التصدير:\n{path}")
        except Exception as e:
            messagebox.showerror("خطأ",str(e))

    # ══════════════════════════════════
    #  الواجهة الرئيسية
    # ══════════════════════════════════
    def show_main(self):
        self.clear()

        # TOP BAR
        topbar = ctk.CTkFrame(self, height=62, fg_color=C["topbar"], corner_radius=0)
        topbar.pack(side="top", fill="x")
        topbar.pack_propagate(False)

        brand = ctk.CTkFrame(topbar, fg_color="transparent"); brand.pack(side="right",padx=16,pady=8)
        if self._logo_sized(40,40):
            ctk.CTkLabel(brand, image=self._logo_sized(40,40), text="").pack(side="right",padx=(0,10))
        nc = ctk.CTkFrame(brand, fg_color="transparent"); nc.pack(side="right")
        ctk.CTkLabel(nc, text="ARKAN SCHOOL",
                     font=("Tahoma",17,"bold"), text_color=C["gold"]).pack(anchor="e")
        ctk.CTkLabel(nc, text="منظومة أركان  ·  V35 PRO",
                     font=("Tahoma",10), text_color=C["muted"]).pack(anchor="e")

        ctk.CTkFrame(topbar, width=1, fg_color=C["border"]).pack(side="right",fill="y",pady=12,padx=6)

        role_label = ROLE_LABELS.get(self.current_role or "viewer","—")
        uf = ctk.CTkFrame(topbar, fg_color="transparent"); uf.pack(side="right",padx=12)
        ctk.CTkLabel(uf, text=f"👤  {self.current_username}",
                     font=("Tahoma",12,"bold"), text_color=C["text"]).pack(anchor="e")
        ctk.CTkLabel(uf, text=role_label, font=("Tahoma",10),
                     text_color=C["gold"]).pack(anchor="e")

        ctk.CTkButton(topbar, text="خروج 🚪", command=self.show_login,
            fg_color=C["card2"], hover_color=C["red2"],
            text_color=C["muted"], font=("Tahoma",11,"bold"),
            width=90, height=36, corner_radius=10).pack(side="left",padx=14,pady=12)

        # MAIN AREA
        main = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        main.pack(fill="both",expand=True)

        # SIDEBAR
        self.sidebar = ctk.CTkFrame(main, width=270, corner_radius=0, fg_color="#1E3A5F")
        self.sidebar.pack(side="right", fill="y")
        self.sidebar.pack_propagate(False)

        # شعار واسم المدرسة
        lf = ctk.CTkFrame(self.sidebar, fg_color="#162F4E", corner_radius=0)
        lf.pack(fill="x", pady=0)
        if self._logo_sized(80, 80):
            ctk.CTkLabel(lf, image=self._logo_sized(80, 80), text="").pack(pady=(20, 6))
        ctk.CTkLabel(lf, text="ARKAN SCHOOL",
                     font=("Tahoma", 17, "bold"), text_color="#E5C96A").pack()
        ctk.CTkLabel(lf, text="منظومة أركان المدرسية V35",
                     font=("Tahoma", 10), text_color="#A8C4DC").pack(pady=(2, 4))
        ctk.CTkLabel(lf, text="⚙️ تدفق الأنظمة",
                     font=("Tahoma", 9), text_color="#5EEAD4").pack(pady=(0, 16))

        # خط فاصل ذهبي
        ctk.CTkFrame(self.sidebar, height=2, fg_color="#C8A84B").pack(fill="x", padx=0, pady=0)

        MENU = [
            ("dashboard",  "🏠  لوحة التحكم",        self.dashboard),
            ("classes",    "🏫  الفصول الدراسية",    self.classes_screen),
            ("subjects",   "📚  المواد الدراسية",    self.subjects_screen),
            ("students",   "👨‍🎓  الطلاب",             self.students_screen),
            ("teachers",   "👨‍🏫  المعلمون",           self.teachers_screen),
            ("assign",     "🔗  تكليف المعلمين",     self.teacher_assign_screen),
            ("attendance", "📋  حضور الطلاب",        self.attendance_screen),
            ("att_log",    "🧾  سجل حضور الطلاب",   self.attendance_log_screen),
            ("att_log",    "📅  سجل حضور شهري",     self.monthly_attendance_screen),
            ("teacher_att","👩‍🏫  حضور المعلمين",     self.teacher_att_screen),
            ("grades",     "📊  الدرجات",            self.grades_screen),
            ("notes",      "📝  ملاحظات الطلاب",     self.student_notes_screen),
            ("payments",   "💳  الرسوم والدفع",      self.payments_screen),
            ("reports",    "📊  التقارير المالية",   self.reports_screen),
            ("reports",    "🏆  تقرير الدرجات",      self.full_grades_report),
            ("reports",    "📤  تصدير Excel/CSV",    self.export_screen),
            ("admin_tools","⚙️  إدارة المستخدمين",  self.users_screen),
            ("admin_tools","💰  رواتب المعلمين",     self.salaries_screen),
            ("backup",     "💾  النسخ الاحتياطي",   self.backup_screen),
        ]

        msf = ctk.CTkScrollableFrame(self.sidebar, fg_color="transparent",
            scrollbar_button_color="#2D5A8E",
            scrollbar_button_hover_color="#C8A84B")
        msf.pack(fill="both", expand=True, pady=6)

        for key, text, cmd in MENU:
            allowed = self.has_perm(key)
            ctk.CTkButton(msf, text=text,
                command=(lambda k=key, c=cmd: self.open_page(k, c)),
                height=46, corner_radius=10,
                fg_color="transparent",
                hover_color="#2D5A8E" if allowed else "transparent",
                anchor="e",
                font=("Tahoma", 13, "bold") if allowed else ("Tahoma", 12),
                text_color="#FFFFFF" if allowed else "#5A7A99",
                state="normal" if allowed else "disabled",
                border_spacing=12,
            ).pack(fill="x", padx=8, pady=1)

        # خط فاصل + زر خروج
        ctk.CTkFrame(self.sidebar, height=1, fg_color="#2D5A8E").pack(fill="x", padx=14, pady=6)

        # CONTENT
        self.content = ctk.CTkFrame(main, fg_color=C["bg"], corner_radius=0)
        self.content.pack(fill="both",expand=True)
        self.open_page("dashboard", self.dashboard)

    # ══════════════════════════════════
    #  مساعدات الواجهة
    # ══════════════════════════════════
    def clear_content(self):
        for w in self.content.winfo_children(): w.destroy()

    def page_title(self, title, sub=""):
        h = ctk.CTkFrame(self.content, fg_color=C["bg"])
        h.pack(fill="x",padx=28,pady=(18,4))
        ctk.CTkLabel(h, text=title, font=F["title"], text_color=C["gold"]).pack(anchor="e")
        if sub:
            ctk.CTkLabel(h, text=sub, font=F["sub"], text_color=C["muted"]).pack(anchor="e",pady=(2,0))
        ctk.CTkFrame(self.content, height=3, fg_color=C["gold"], corner_radius=2).pack(fill="x",padx=28,pady=(2,8))

    def _stat_card(self, parent, label, value, icon, accent):
        c = ctk.CTkFrame(parent, fg_color=C["white"], corner_radius=20,
                         border_width=1, border_color=C["border"])
        c.pack(side="right", fill="x", expand=True, padx=7, pady=7)
        ctk.CTkFrame(c, height=4, fg_color=accent, corner_radius=0).pack(fill="x")
        ctk.CTkLabel(c, text=icon, font=("Tahoma",26)).pack(anchor="e",padx=20,pady=(12,2))
        ctk.CTkLabel(c, text=label, font=F["cardl"], text_color=C["muted"]).pack(anchor="e",padx=20)
        ctk.CTkLabel(c, text=value, font=F["cardv"], text_color=accent).pack(anchor="e",padx=20,pady=(4,14))

    def _styled_tree(self, parent, columns, height=10):
        st = ttk.Style()
        st.theme_use("default")
        st.configure("P.Treeview",
            background=C["row_odd"], foreground=C["text"],
            rowheight=34, fieldbackground=C["row_odd"],
            font=F["tree"], borderwidth=0)
        st.configure("P.Treeview.Heading",
            background=C["sidebar"], foreground="#FFFFFF",
            font=F["treeh"], relief="flat", borderwidth=0)
        st.map("P.Treeview",
            background=[("selected", C["sel"])],
            foreground=[("selected", C["text"])])

        wrap = ctk.CTkFrame(parent, fg_color=C["card"], corner_radius=14,
                            border_width=1, border_color=C["border"])
        wrap.pack(fill="both", expand=True, padx=12, pady=(0,10))
        vsb = ttk.Scrollbar(wrap, orient="vertical")
        vsb.pack(side="left", fill="y")
        t = ttk.Treeview(wrap, columns=columns, show="headings",
                         height=height, style="P.Treeview",
                         yscrollcommand=vsb.set)
        vsb.config(command=t.yview)
        for col in columns:
            t.heading(col, text=col, anchor="center")
            t.column(col, anchor="center", width=140, stretch=True)
        t.pack(fill="both", expand=True, padx=4, pady=4)
        t.tag_configure("odd",  background=C["row_odd"])
        t.tag_configure("even", background=C["row_even"])
        t.tag_configure("pass", foreground="#166534")
        t.tag_configure("fail", foreground="#991B1B")
        return t

    def tree(self, columns):
        f = ctk.CTkFrame(self.content, fg_color=C["white"], corner_radius=18,
                         border_width=1, border_color=C["border"])
        f.pack(fill="both", expand=True, padx=28, pady=8)
        return self._styled_tree(f, columns)

    def input(self, parent, placeholder, width=160):
        e = ctk.CTkEntry(parent, width=width, height=40,
            placeholder_text=placeholder, justify="right",
            font=F["entry"], fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=10)
        e.pack(side="right",padx=5,pady=5)
        return e

    def combo(self, parent, values, width=200):
        c = ctk.CTkComboBox(parent, values=values or ["—"], width=width, height=40,
            justify="center", fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], corner_radius=10)
        c.pack(side="right",padx=5,pady=5)
        if values: c.set(values[0])
        return c

    def btn(self, parent, text, cmd, color=None, width=120):
        color = color or C["gold"]
        tc = "#060D18" if color == C["gold"] else C["white"]
        hv = C["gold2"] if color == C["gold"] else color
        b = ctk.CTkButton(parent, text=text, command=cmd,
            fg_color=color, hover_color=hv, text_color=tc,
            font=F["btn"], height=40, width=width, corner_radius=10)
        b.pack(side="right",padx=5,pady=5)
        return b

    def form_frame(self):
        f = ctk.CTkFrame(self.content, fg_color=C["white"], corner_radius=16,
                         border_width=1, border_color=C["border"])
        f.pack(fill="x", padx=28, pady=6)
        return f

    # ── DB helpers ──
    def get_classes(self):
        con = connect(); cur = con.cursor()
        cur.execute("SELECT id,class_name,section,academic_year FROM classes ORDER BY id")
        rows = cur.fetchall(); con.close(); return rows

    def get_visible_classes(self):
        rows = self.get_classes()
        if self.current_role != "teacher": return rows
        con = connect(); cur = con.cursor()
        cur.execute("SELECT DISTINCT class_id FROM teacher_assignments WHERE username=?",
                    (self.current_username,))
        allowed = {r[0] for r in cur.fetchall()}; con.close()
        return [r for r in rows if r[0] in allowed]

    def get_teacher_scope(self):
        con = connect(); cur = con.cursor()
        cur.execute("SELECT DISTINCT class_id FROM teacher_assignments WHERE username=?",
                    (self.current_username,))
        cids = {r[0] for r in cur.fetchall()}
        cur.execute("SELECT DISTINCT subject_id FROM teacher_assignments WHERE username=?",
                    (self.current_username,))
        sids = {r[0] for r in cur.fetchall()}
        con.close(); return cids, sids

    def can_access_student(self, sid):
        if self.current_role != "teacher": return True
        cids, _ = self.get_teacher_scope()
        con = connect(); cur = con.cursor()
        cur.execute("SELECT class_id FROM students WHERE id=?",(sid,))
        row = cur.fetchone(); con.close()
        return bool(row and row[0] in cids)

    # ══════════════════════════════════
    #  لوحة التحكم — مع أنماط ورسوم بيانية
    # ══════════════════════════════════
    def dashboard(self):
        self.clear_content()

        # إطار قابل للتمرير بدون CTkScrollableFrame لضمان الظهور الصحيح
        outer = ctk.CTkFrame(self.content, fg_color=C["bg"], corner_radius=0)
        outer.pack(fill="both", expand=True)

        canvas_scroll = tk.Canvas(outer, bg=C["bg"], bd=0, highlightthickness=0)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas_scroll.yview)
        canvas_scroll.configure(yscrollcommand=vsb.set)
        vsb.pack(side="left", fill="y")
        canvas_scroll.pack(side="right", fill="both", expand=True)

        scroll = ctk.CTkFrame(canvas_scroll, fg_color=C["bg"], corner_radius=0)
        scroll_win = canvas_scroll.create_window((0, 0), window=scroll, anchor="nw")

        def _on_frame_configure(e):
            canvas_scroll.configure(scrollregion=canvas_scroll.bbox("all"))
        def _on_canvas_configure(e):
            canvas_scroll.itemconfig(scroll_win, width=e.width)
        def _on_mousewheel(e):
            canvas_scroll.yview_scroll(int(-1*(e.delta/120)), "units")

        scroll.bind("<Configure>", _on_frame_configure)
        canvas_scroll.bind("<Configure>", _on_canvas_configure)
        canvas_scroll.bind("<MouseWheel>", _on_mousewheel)
        scroll.bind("<MouseWheel>", _on_mousewheel)

        # ══ بانر الترحيب ═════════════════════════════════
        banner = ctk.CTkFrame(scroll, fg_color="#1E3A5F", corner_radius=22, height=148)
        banner.pack(fill="x", padx=24, pady=(16, 8))
        banner.pack_propagate(False)
        ctk.CTkFrame(banner, height=5, fg_color="#C8A84B", corner_radius=0).pack(fill="x")

        inner = ctk.CTkFrame(banner, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=20, pady=6)

        if self._logo_sized(95, 95):
            ctk.CTkLabel(inner, image=self._logo_sized(95, 95), text="").pack(side="right", padx=(0, 10))

        tc = ctk.CTkFrame(inner, fg_color="transparent")
        tc.pack(side="right", fill="y", pady=8)
        ctk.CTkLabel(tc, text="ARKAN SCHOOL",
                     font=("Tahoma", 28, "bold"), text_color="#E5C96A").pack(anchor="e")
        ctk.CTkLabel(tc, text="منظومة أركان المدرسية  ·  V35 PRO",
                     font=("Tahoma", 13), text_color="#A8C4DC").pack(anchor="e", pady=(2, 3))
        ctk.CTkLabel(tc,
                     text=f"📅  {date.today().strftime('%A  %Y/%m/%d')}   |   مرحباً  {self.current_username or ''}",
                     font=("Tahoma", 12), text_color="#7AACCC").pack(anchor="e")
        ctk.CTkLabel(tc, text="⚙️  تدفق الأنظمة  ·  Tadafuq Systems",
                     font=("Tahoma", 10), text_color="#5EEAD4").pack(anchor="e", pady=(4, 0))

        # إحصائيات سريعة في البانر
        con = connect(); cur = con.cursor()
        cur.execute("SELECT COUNT(*) FROM students");  ns = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM teachers");  nt = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM classes");   nc = cur.fetchone()[0]
        cur.execute("SELECT IFNULL(SUM(total_fees),0),IFNULL(SUM(paid_fees),0) FROM students")
        total_f, paid_f = cur.fetchone()
        today_str = str(date.today())
        cur.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='حاضر' AND person_type='طالب'", (today_str,))
        pres = cur.fetchone()[0]
        att_pct = round(pres / ns * 100) if ns > 0 else 0

        qf = ctk.CTkFrame(inner, fg_color="transparent")
        qf.pack(side="left", fill="y", padx=(0, 10), pady=10)
        for lbl, val, clr in [("طالب", str(ns), "#E5C96A"), ("معلم", str(nt), "#5EEAD4"), ("فصل", str(nc), "#93C5FD")]:
            qc = ctk.CTkFrame(qf, fg_color="#162F4E", corner_radius=12, width=82, height=72)
            qc.pack(side="left", padx=5); qc.pack_propagate(False)
            ctk.CTkLabel(qc, text=val, font=("Tahoma", 22, "bold"), text_color=clr).pack(pady=(10, 0))
            ctk.CTkLabel(qc, text=lbl, font=("Tahoma", 11), text_color="#A8C4DC").pack()
        ctk.CTkFrame(banner, height=3, fg_color="#C8A84B", corner_radius=0).pack(fill="x", side="bottom")

        # ══ بطاقات الإحصاء الكبيرة ═══════════════════════
        cur.execute("SELECT COUNT(*) FROM students WHERE total_fees-paid_fees>0")
        late_fees = cur.fetchone()[0]
        cur.execute("""SELECT IFNULL(classes.class_name||' '||classes.section,students.grade),
                       COUNT(*) cnt FROM attendance JOIN students ON attendance.person_id=students.id
                       WHERE attendance.person_type='طالب' AND attendance.status='غائب' AND attendance.day=?
                       GROUP BY 1 ORDER BY cnt DESC LIMIT 1""", (today_str,))
        most_absent = cur.fetchone()
        cur.execute("""SELECT students.name, AVG(grades.total_score) avg FROM grades
                       JOIN students ON grades.student_id=students.id
                       GROUP BY students.id ORDER BY avg DESC LIMIT 1""")
        best_s = cur.fetchone()
        cur.execute("""SELECT teachers.name, COUNT(*) cnt FROM attendance
                       JOIN teachers ON attendance.person_id=teachers.id
                       WHERE attendance.person_type='معلم' AND attendance.status='حاضر'
                       GROUP BY teachers.id ORDER BY cnt DESC LIMIT 1""")
        best_t = cur.fetchone()

        r1 = ctk.CTkFrame(scroll, fg_color=C["bg"]); r1.pack(fill="x", padx=16, pady=(6, 0))
        self._stat_card(r1, "الطلاب",       str(ns),          "👨‍🎓", C["gold"])
        self._stat_card(r1, "المعلمون",     str(nt),          "👨‍🏫", C["teal"])
        self._stat_card(r1, "الفصول",      str(nc),          "🏫",  C["gold"])
        self._stat_card(r1, "نسبة الحضور", f"{att_pct}%",    "📋",  C["teal"])

        r2 = ctk.CTkFrame(scroll, fg_color=C["bg"]); r2.pack(fill="x", padx=16, pady=0)
        self._stat_card(r2, "إجمالي الرسوم",  f"{total_f:.0f} د.ل",   "💰", C["gold"])
        self._stat_card(r2, "المدفوع",         f"{paid_f:.0f} د.ل",    "✅", C["teal"])
        self._stat_card(r2, "رسوم متأخرة",    f"{late_fees} طالب",    "⚠️", C["red"])
        self._stat_card(r2, "أكثر فصل غياباً", most_absent[0] if most_absent else "—", "📉", C["orange"])

        r3 = ctk.CTkFrame(scroll, fg_color=C["bg"]); r3.pack(fill="x", padx=16, pady=(0, 8))
        self._stat_card(r3, "أفضل طالب", best_s[0] if best_s else "—", "🏆", C["gold"])
        self._stat_card(r3, "أفضل معلم", best_t[0] if best_t else "—", "⭐", C["teal"])

        # ══ صف الرسوم البيانية الرئيسية ══════════════════
        charts_row = ctk.CTkFrame(scroll, fg_color=C["bg"])
        charts_row.pack(fill="x", padx=16, pady=(4, 8))

        # ── مخطط عمودي: حضور آخر 7 أيام ─────────────────
        att_card = ctk.CTkFrame(charts_row, fg_color=C["card"], corner_radius=18,
                                border_width=1, border_color=C["border"])
        att_card.pack(side="right", fill="both", expand=True, padx=(0, 6))
        ctk.CTkFrame(att_card, height=4, fg_color=C["teal"], corner_radius=0).pack(fill="x")
        ctk.CTkLabel(att_card, text="📊  الحضور اليومي — آخر 7 أيام",
                     font=F["head"], text_color=C["teal"]).pack(anchor="e", padx=18, pady=(12, 4))

        from datetime import timedelta
        days7 = [(date.today() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(6, -1, -1)]
        att_data = []
        for d in days7:
            cur.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='حاضر' AND person_type='طالب'", (d,))
            p = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM attendance WHERE day=? AND status='غائب' AND person_type='طالب'", (d,))
            ab = cur.fetchone()[0]
            att_data.append((d[-5:], p, ab))  # MM-DD

        self._draw_bar_chart(att_card, att_data,
                             colors=(C["teal"], C["red"]),
                             legend=("حاضر", "غائب"),
                             height=200)

        # ── مخطط دائري: الرسوم ─────────────────────────
        fee_card = ctk.CTkFrame(charts_row, fg_color=C["card"], corner_radius=18,
                                border_width=1, border_color=C["border"])
        fee_card.pack(side="right", fill="both", expand=True, padx=(6, 0))
        ctk.CTkFrame(fee_card, height=4, fg_color=C["gold"], corner_radius=0).pack(fill="x")
        ctk.CTkLabel(fee_card, text="💰  نسبة تحصيل الرسوم",
                     font=F["head"], text_color=C["gold"]).pack(anchor="e", padx=18, pady=(12, 4))
        self._draw_donut_chart(fee_card, paid_f, total_f - paid_f,
                               labels=("مدفوع", "متبقي"),
                               colors=(C["teal"], C["red"]),
                               height=200)

        # ══ صف ثانٍ: توزيع الطلاب + أداء الفصول ═════════
        charts_row2 = ctk.CTkFrame(scroll, fg_color=C["bg"])
        charts_row2.pack(fill="x", padx=16, pady=(0, 8))

        # ── مخطط أعمدة: عدد الطلاب في كل فصل ───────────
        dist_card = ctk.CTkFrame(charts_row2, fg_color=C["card"], corner_radius=18,
                                 border_width=1, border_color=C["border"])
        dist_card.pack(side="right", fill="both", expand=True, padx=(0, 6))
        ctk.CTkFrame(dist_card, height=4, fg_color=C["gold"], corner_radius=0).pack(fill="x")
        ctk.CTkLabel(dist_card, text="🏫  توزيع الطلاب على الفصول",
                     font=F["head"], text_color=C["gold"]).pack(anchor="e", padx=18, pady=(12, 4))
        cur.execute("""SELECT c.class_name||' '||c.section, COUNT(s.id)
                       FROM classes c LEFT JOIN students s ON s.class_id=c.id
                       GROUP BY c.id ORDER BY COUNT(s.id) DESC LIMIT 8""")
        class_dist = [(r[0][:8], r[1], 0) for r in cur.fetchall()]
        self._draw_bar_chart(dist_card, class_dist,
                             colors=(C["gold"], C["gold"]),
                             legend=("عدد الطلاب", None),
                             height=200, single=True)

        # ── مخطط أداء: متوسط الدرجات لكل فصل ────────────
        perf_card = ctk.CTkFrame(charts_row2, fg_color=C["card"], corner_radius=18,
                                 border_width=1, border_color=C["border"])
        perf_card.pack(side="right", fill="both", expand=True, padx=(6, 0))
        ctk.CTkFrame(perf_card, height=4, fg_color="#7C3AED", corner_radius=0).pack(fill="x")
        ctk.CTkLabel(perf_card, text="🏆  متوسط الدرجات لكل فصل",
                     font=F["head"], text_color="#7C3AED").pack(anchor="e", padx=18, pady=(12, 4))
        cur.execute("""SELECT c.class_name||' '||c.section, ROUND(AVG(g.total_score),1)
                       FROM grades g JOIN students s ON g.student_id=s.id
                       JOIN classes c ON s.class_id=c.id
                       GROUP BY c.id ORDER BY AVG(g.total_score) DESC LIMIT 8""")
        perf_data = [(r[0][:8], r[1] or 0, 0) for r in cur.fetchall()]
        self._draw_bar_chart(perf_card, perf_data,
                             colors=("#7C3AED", "#7C3AED"),
                             legend=("المتوسط", None),
                             height=200, single=True, max_val=100)

        # ══ آخر 5 دفعات + آخر 5 غيابات ══════════════════
        bottom_row = ctk.CTkFrame(scroll, fg_color=C["bg"])
        bottom_row.pack(fill="x", padx=16, pady=(0, 16))

        # ── آخر الدفعات ────────────────────────────────
        pay_card = ctk.CTkFrame(bottom_row, fg_color=C["card"], corner_radius=18,
                                border_width=1, border_color=C["border"])
        pay_card.pack(side="right", fill="both", expand=True, padx=(0, 6))
        ctk.CTkFrame(pay_card, height=4, fg_color=C["teal"], corner_radius=0).pack(fill="x")
        ctk.CTkLabel(pay_card, text="💳  آخر الدفعات المسجّلة",
                     font=F["head"], text_color=C["teal"]).pack(anchor="e", padx=18, pady=(12, 6))
        cur.execute("""SELECT s.name, p.amount, p.pay_date
                       FROM payments p JOIN students s ON p.student_id=s.id
                       ORDER BY p.id DESC LIMIT 5""")
        pt = self._styled_tree(pay_card, ["الطالب","المبلغ","التاريخ"], height=5)
        for row in cur.fetchall(): pt.insert("","end",values=row)

        # ── آخر الغيابات ───────────────────────────────
        ab_card = ctk.CTkFrame(bottom_row, fg_color=C["card"], corner_radius=18,
                               border_width=1, border_color=C["border"])
        ab_card.pack(side="right", fill="both", expand=True, padx=(6, 0))
        ctk.CTkFrame(ab_card, height=4, fg_color=C["red"], corner_radius=0).pack(fill="x")
        ctk.CTkLabel(ab_card, text="🔴  آخر الغيابات",
                     font=F["head"], text_color=C["red"]).pack(anchor="e", padx=18, pady=(12, 6))
        cur.execute("""SELECT s.name, IFNULL(c.class_name||' '||c.section,s.grade), a.day
                       FROM attendance a JOIN students s ON a.person_id=s.id
                       LEFT JOIN classes c ON s.class_id=c.id
                       WHERE a.person_type='طالب' AND a.status='غائب'
                       ORDER BY a.id DESC LIMIT 5""")
        abt = self._styled_tree(ab_card, ["الطالب","الفصل","التاريخ"], height=5)
        for row in cur.fetchall(): abt.insert("","end",values=row)

        con.close()

    # ══════════════════════════════════
    #  مساعدات الرسوم البيانية (Canvas)
    # ══════════════════════════════════
    def _draw_bar_chart(self, parent, data, colors, legend, height=220,
                        single=False, max_val=None):
        """رسم مخطط عمودي بـ Canvas — عرض ثابت لضمان الظهور"""
        if not data:
            ctk.CTkLabel(parent, text="لا توجد بيانات كافية",
                         font=F["sub"], text_color=C["muted"]).pack(pady=20)
            return

        W_FIXED = 480  # عرض ثابت كافٍ
        cv = tk.Canvas(parent, height=height, width=W_FIXED,
                       bg=C["card"], bd=0, highlightthickness=0)
        cv.pack(fill="x", padx=12, pady=(0, 10))

        def draw(W=None):
            cv.delete("all")
            W = cv.winfo_width()
            if W < 30: W = W_FIXED
            H = height

            pad_l, pad_r, pad_t, pad_b = 32, 12, 24, 42
            chart_w = W - pad_l - pad_r
            chart_h = H - pad_t - pad_b

            vals1 = [d[1] for d in data]
            vals2 = [] if single else [d[2] for d in data]
            all_vals = vals1 + (vals2 if vals2 else [])
            top = max_val if max_val else (max(all_vals) if max(all_vals) > 0 else 1)

            n = len(data)
            group_w = chart_w / n
            bar_w = group_w * (0.5 if single else 0.35)

            # خطوط شبكة + قيم المحور Y
            for i in range(5):
                y = pad_t + chart_h - (chart_h * i / 4)
                cv.create_line(pad_l, y, W - pad_r, y,
                               fill="#CBD5E1", width=1, dash=(4, 3))
                v = round(top * i / 4)
                cv.create_text(pad_l - 4, y, text=str(v),
                               anchor="e", font=("Tahoma", 8), fill=C["muted"])

            # خط المحور الأفقي
            cv.create_line(pad_l, pad_t + chart_h, W - pad_r, pad_t + chart_h,
                           fill=C["border"], width=1)

            for i, (lbl, v1, v2) in enumerate(data):
                cx_bar = pad_l + i * group_w + group_w / 2

                # عمود 1
                h1 = max((v1 / top) * chart_h, 2) if (top > 0 and v1 > 0) else 0
                if single:
                    x0 = cx_bar - bar_w / 2
                    x1 = cx_bar + bar_w / 2
                else:
                    x0 = cx_bar - bar_w * 1.05
                    x1 = cx_bar - 0.05 * bar_w
                y0 = pad_t + chart_h - h1
                y1 = pad_t + chart_h
                if h1 > 0:
                    cv.create_rectangle(x0, y0, x1, y1, fill=colors[0], outline="")
                    cv.create_text((x0+x1)/2, y0 - 5, text=str(int(v1)),
                                   font=("Tahoma", 8, "bold"), fill=colors[0])

                if not single:
                    h2 = max((v2 / top) * chart_h, 2) if (top > 0 and v2 > 0) else 0
                    x0b = cx_bar + 0.05 * bar_w
                    x1b = cx_bar + bar_w * 1.05
                    y0b = pad_t + chart_h - h2
                    if h2 > 0:
                        cv.create_rectangle(x0b, y0b, x1b, y1, fill=colors[1], outline="")
                        cv.create_text((x0b+x1b)/2, y0b - 5, text=str(int(v2)),
                                       font=("Tahoma", 8, "bold"), fill=colors[1])

                # تسمية محور X
                cv.create_text(cx_bar, H - pad_b + 10, text=lbl,
                               font=("Tahoma", 8), fill=C["muted"], anchor="n")

            # وسيلة الإيضاح
            if legend and legend[0]:
                cv.create_rectangle(W - 100, 6, W - 92, 14, fill=colors[0], outline="")
                cv.create_text(W - 88, 10, text=legend[0],
                               anchor="w", font=("Tahoma", 9), fill=C["muted"])
            if not single and legend and legend[1]:
                cv.create_rectangle(W - 100, 18, W - 92, 26, fill=colors[1], outline="")
                cv.create_text(W - 88, 22, text=legend[1],
                               anchor="w", font=("Tahoma", 9), fill=C["muted"])

        cv.bind("<Configure>", lambda e: draw())
        # إعادة الرسم بعد أن تُعرض النافذة كاملاً
        cv.after(100, draw)
        cv.after(400, draw)
        cv.after(900, draw)

    def _draw_donut_chart(self, parent, val1, val2, labels, colors, height=220):
        """رسم مخطط دائري (Donut) بـ Canvas"""
        W_FIXED = 420
        cv = tk.Canvas(parent, height=height, width=W_FIXED,
                       bg=C["card"], bd=0, highlightthickness=0)
        cv.pack(fill="x", padx=12, pady=(0, 10))

        def draw():
            cv.delete("all")
            W = cv.winfo_width()
            if W < 30: W = W_FIXED
            H = height

            total = val1 + val2
            # الدائرة على اليسار (RTL: اليمين في الشاشة)
            r = min(H // 2 - 18, 80)
            ri = int(r * 0.56)
            ox = W - r - 30  # مركز الدائرة
            oy = H // 2

            def arc(start, extent, color):
                cv.create_arc(ox - r, oy - r, ox + r, oy + r,
                              start=start, extent=extent,
                              fill=color, outline=C["card"], width=3, style="pieslice")

            if total <= 0:
                arc(0, 359.9, C["border"])
                cv.create_oval(ox-ri, oy-ri, ox+ri, oy+ri, fill=C["card"], outline=C["card"])
                cv.create_text(ox, oy, text="لا بيانات", font=("Tahoma", 10), fill=C["muted"])
            else:
                pct1 = val1 / total
                ext1 = pct1 * 359.9
                arc(90, ext1, colors[0])
                arc(90 + ext1, 359.9 - ext1, colors[1])
                cv.create_oval(ox-ri, oy-ri, ox+ri, oy+ri, fill=C["card"], outline=C["card"])
                cv.create_text(ox, oy - 10, text=f"{round(pct1*100)}%",
                               font=("Tahoma", 16, "bold"), fill=colors[0])
                cv.create_text(ox, oy + 10, text=labels[0],
                               font=("Tahoma", 9), fill=C["muted"])

            # أسطورة على اليمين
            lx = 20
            for i, (lbl, clr, val) in enumerate([(labels[0], colors[0], val1),
                                                  (labels[1], colors[1], val2)]):
                ly = H // 2 - 18 + i * 36
                cv.create_rectangle(lx, ly, lx + 16, ly + 16, fill=clr, outline="")
                cv.create_text(lx + 22, ly + 8, text=f"{lbl}",
                               anchor="w", font=("Tahoma", 10, "bold"), fill=clr)
                cv.create_text(lx + 22, ly + 22, text=f"{val:.0f} د.ل",
                               anchor="w", font=("Tahoma", 9), fill=C["muted"])

        cv.bind("<Configure>", lambda e: draw())
        cv.after(100, draw)
        cv.after(400, draw)
        cv.after(900, draw)


    def classes_screen(self):
        self.clear_content()
        self.page_title("الفصول الدراسية","إدارة الصفوف والشعب")
        form = self.form_frame()
        cn = self.input(form,"الصف",150)
        sc = self.input(form,"الشعبة",100)
        yr = self.input(form,"السنة",130); yr.insert(0,"2026-2027")
        def add():
            if not cn.get().strip(): messagebox.showwarning("تنبيه","اكتب اسم الصف"); return
            con=connect(); cur=con.cursor()
            cur.execute("INSERT INTO classes(class_name,section,academic_year) VALUES(?,?,?)",
                        (cn.get().strip(),sc.get().strip(),yr.get().strip()))
            con.commit(); con.close(); self.classes_screen()
        def delete_c():
            sel = t.focus()
            if not sel: messagebox.showwarning("تنبيه","اختر فصلاً"); return
            cid = int(t.item(sel,"values")[0])
            if not messagebox.askyesno("تأكيد","حذف الفصل؟"): return
            con=connect(); cur=con.cursor()
            cur.execute("DELETE FROM classes WHERE id=?",(cid,))
            con.commit(); con.close(); self.classes_screen()
        self.btn(form,"إضافة",add,C["teal"],100)
        self.btn(form,"حذف المحدد",delete_c,C["red"],120)
        t = self.tree(["ID","الصف","الشعبة","السنة"])
        con=connect(); cur=con.cursor()
        cur.execute("SELECT id,class_name,section,academic_year FROM classes ORDER BY id")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  المواد
    # ══════════════════════════════════
    def subjects_screen(self):
        self.clear_content()
        self.page_title("المواد الدراسية","ربط المواد بالفصول")
        form = self.form_frame()
        sub = self.input(form,"اسم المادة",180)
        classes = self.get_classes()
        cmap = {f"{r[1]} {r[2]}": r[0] for r in classes}
        cbox = self.combo(form, list(cmap.keys()), 220)
        def add():
            if not sub.get().strip(): messagebox.showwarning("تنبيه","اكتب اسم المادة"); return
            cid = cmap.get(cbox.get())
            con=connect(); cur=con.cursor()
            cur.execute("INSERT INTO subjects(subject_name,class_id) VALUES(?,?)",(sub.get().strip(),cid))
            con.commit(); con.close(); self.subjects_screen()
        def delete_s():
            sel=t.focus()
            if not sel: return
            sid=int(t.item(sel,"values")[0])
            if not messagebox.askyesno("تأكيد","حذف المادة؟"): return
            con=connect(); cur=con.cursor()
            cur.execute("DELETE FROM subjects WHERE id=?",(sid,)); con.commit(); con.close()
            self.subjects_screen()
        self.btn(form,"إضافة",add,C["teal"],100)
        self.btn(form,"حذف",delete_s,C["red"],100)
        t = self.tree(["ID","المادة","الفصل"])
        con=connect(); cur=con.cursor()
        cur.execute("""SELECT subjects.id, subjects.subject_name,
                       IFNULL(classes.class_name||' '||classes.section,'بدون فصل')
                       FROM subjects LEFT JOIN classes ON subjects.class_id=classes.id
                       ORDER BY subjects.id DESC""")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  الطلاب
    # ══════════════════════════════════
    def students_screen(self):
        self.clear_content()
        self.page_title("الطلاب","إضافة وتعديل وحذف بيانات الطلاب")
        form = self.form_frame()
        nm  = self.input(form,"اسم الطالب",170)
        ph  = self.input(form,"هاتف ولي الأمر",155)
        fs  = self.input(form,"الرسوم",110)
        classes = self.get_classes()
        cmap = {f"{r[1]} {r[2]}": r[0] for r in classes}
        cbox = self.combo(form, list(cmap.keys()), 230)
        eid = {"v": None}

        def clear_f():
            eid["v"]=None
            for e in [nm,ph,fs]: e.delete(0,"end")
            if classes: cbox.set(list(cmap.keys())[0])

        def add():
            try:
                sn=nm.get().strip()
                if not sn: messagebox.showwarning("تنبيه","اكتب اسم الطالب"); return
                cid=cmap.get(cbox.get()); grade=cbox.get()
                con=connect(); cur=con.cursor()
                cur.execute("""INSERT INTO students(name,grade,parent_phone,parent_code,total_fees,paid_fees,class_id)
                               VALUES(?,?,?,?,?,0,?)""",
                            (sn, grade, ph.get().strip(), "", float(fs.get() or 0), cid))
                new_id = cur.lastrowid
                cur.execute("UPDATE students SET parent_code=? WHERE id=?",
                            (f"ARK-{1000+new_id}", new_id))
                con.commit(); con.close()
                messagebox.showinfo("تم",f"تمت الإضافة\nكود ولي الأمر: ARK-{1000+new_id}")
                show_toast(self, f"✅  تمت إضافة الطالب: {sn}")
                self.students_screen()
            except Exception as e: messagebox.showerror("خطأ",str(e))

        def load_edit():
            sel=t.focus()
            if not sel: messagebox.showwarning("تنبيه","اختر طالباً"); return
            v=t.item(sel,"values")
            eid["v"]=int(v[0])
            nm.delete(0,"end"); nm.insert(0,v[1])
            ph.delete(0,"end"); ph.insert(0,v[3])
            fs.delete(0,"end"); fs.insert(0,v[4])
            try: cbox.set(v[2])
            except: pass

        def save_edit():
            if not eid["v"]: messagebox.showwarning("تنبيه","اختر طالباً أولاً"); return
            try:
                cid=cmap.get(cbox.get())
                con=connect(); cur=con.cursor()
                cur.execute("""UPDATE students SET name=?,grade=?,parent_phone=?,
                               total_fees=?,class_id=? WHERE id=?""",
                            (nm.get().strip(), cbox.get(), ph.get().strip(),
                             float(fs.get() or 0), cid, eid["v"]))
                con.commit(); con.close()
                messagebox.showinfo("تم","تم حفظ التعديل"); self.students_screen()
            except Exception as e: messagebox.showerror("خطأ",str(e))

        def copy_code():
            sel=t.focus()
            if not sel: return
            v=t.item(sel,"values")
            txt=f"الطالب: {v[1]}\nكود ولي الأمر: {v[5]}\nرقم الهاتف: {v[3]}"
            self.clipboard_clear(); self.clipboard_append(txt)
            messagebox.showinfo("تم","تم نسخ بيانات ولي الأمر")

        def delete_s():
            sel=t.focus()
            if not sel: return
            v=t.item(sel,"values")
            if not messagebox.askyesno("تأكيد",f"حذف الطالب: {v[1]}؟"): return
            sid=int(v[0])
            con=connect(); cur=con.cursor()
            for q in ["DELETE FROM students WHERE id=?",
                      "DELETE FROM payments WHERE student_id=?",
                      "DELETE FROM grades WHERE student_id=?",
                      "DELETE FROM student_notes WHERE student_id=?",
                      "DELETE FROM notifications WHERE student_id=?"]:
                cur.execute(q,(sid,))
            cur.execute("DELETE FROM attendance WHERE person_type='طالب' AND person_id=?",(sid,))
            con.commit(); con.close()
            messagebox.showinfo("تم","تم الحذف"); self.students_screen()

        def whatsapp_selected():
            """فتح واتساب للطالب المحدد"""
            sel = t.focus()
            if not sel:
                messagebox.showwarning("تنبيه", "اختر طالباً من القائمة أولاً"); return
            v = t.item(sel, "values")
            name = v[1]; phone = normalize_phone(v[3])
            remaining = v[7]
            if not phone or phone == "0":
                messagebox.showwarning("تنبيه", f"لا يوجد رقم هاتف للطالب: {name}"); return
            # تحويل الرقم الليبي لصيغة دولية
            if phone.startswith("0"):
                phone = "218" + phone[1:]
            msg = f"السلام عليكم ولي أمر الطالب {name}،\nنذكركم بأن المتبقي من رسوم الدراسة: {remaining} د.ل\nيُرجى التواصل مع إدارة المدرسة.\nشكراً — أركان المدرسية"
            url = f"https://wa.me/{phone}?text={urllib.parse.quote(msg)}"
            webbrowser.open(url)

        def whatsapp_absent():
            """إرسال إشعار غياب اليوم عبر واتساب"""
            sel = t.focus()
            if not sel:
                messagebox.showwarning("تنبيه", "اختر طالباً من القائمة أولاً"); return
            v = t.item(sel, "values")
            name = v[1]; phone = normalize_phone(v[3])
            if not phone or phone == "0":
                messagebox.showwarning("تنبيه", f"لا يوجد رقم هاتف للطالب: {name}"); return
            if phone.startswith("0"):
                phone = "218" + phone[1:]
            today_str = date.today().strftime("%Y/%m/%d")
            msg = f"السلام عليكم ولي أمر الطالب {name}،\nنُعلمكم بأن ابنكم/ابنتكم تغيّب عن المدرسة اليوم {today_str}.\nيُرجى التواصل مع الإدارة.\nأركان المدرسية"
            url = f"https://wa.me/{phone}?text={urllib.parse.quote(msg)}"
            webbrowser.open(url)

        def whatsapp_bulk_fees():
            """إرسال واتساب لجميع المتأخرين في الرسوم"""
            con2 = connect(); cur2 = con2.cursor()
            cur2.execute("""SELECT name, parent_phone, total_fees-paid_fees
                           FROM students WHERE total_fees-paid_fees>0 AND parent_phone!=''""")
            rows = cur2.fetchall(); con2.close()
            if not rows:
                messagebox.showinfo("معلومة", "لا يوجد طلاب متأخرون في الرسوم"); return
            if not messagebox.askyesno("تأكيد",
                f"سيتم فتح واتساب لـ {len(rows)} ولي أمر متأخر في الرسوم.\nهل تريد المتابعة؟"): return
            for name, phone, remaining in rows:
                phone = normalize_phone(phone)
                if not phone or phone == "0": continue
                if phone.startswith("0"): phone = "218" + phone[1:]
                msg = f"السلام عليكم ولي أمر الطالب {name}،\nنذكركم بأن المتبقي من الرسوم: {remaining:.0f} د.ل\nيُرجى التسوية في أقرب وقت.\nأركان المدرسية"
                url = f"https://wa.me/{phone}?text={urllib.parse.quote(msg)}"
                webbrowser.open(url)

        def import_excel():
            """استيراد بيانات الطلاب من Excel"""
            try:
                import openpyxl
            except ImportError:
                messagebox.showerror("خطأ",
                    "مكتبة openpyxl غير مثبتة.\nشغّل الأمر:\npip install openpyxl"); return

            path = filedialog.askopenfilename(
                title="اختر ملف Excel",
                filetypes=[("Excel","*.xlsx *.xls"), ("كل الملفات","*.*")])
            if not path: return

            # عرض نافذة المعاينة
            try:
                wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
                ws = wb.active
                rows_raw = list(ws.iter_rows(values_only=True))
                wb.close()
            except Exception as e:
                messagebox.showerror("خطأ", f"تعذّر فتح الملف:\n{e}"); return

            if len(rows_raw) < 2:
                messagebox.showwarning("تنبيه", "الملف فارغ أو يحتوي على سطر واحد فقط"); return

            # نافذة معاينة وتحديد الأعمدة
            win = ctk.CTkToplevel(self)
            win.title("استيراد من Excel")
            win.geometry("780x560")
            win.transient(self); win.grab_set()
            win.configure(fg_color=C["bg"])

            ctk.CTkLabel(win, text="📥  استيراد الطلاب من Excel",
                         font=F["head"], text_color=C["gold"]).pack(pady=(18, 4))
            ctk.CTkLabel(win,
                text=f"تم قراءة {len(rows_raw)-1} سجل من الملف. حدّد الأعمدة المناسبة:",
                font=F["sub"], text_color=C["muted"]).pack(pady=(0, 8))

            # قراءة أسماء الأعمدة من السطر الأول
            headers = [str(c or f"عمود {i+1}") for i, c in enumerate(rows_raw[0])]
            col_opts = ["— لا يوجد —"] + headers

            cfg = ctk.CTkFrame(win, fg_color=C["card"], corner_radius=16)
            cfg.pack(fill="x", padx=24, pady=4)

            def make_row(label, default_search):
                r = ctk.CTkFrame(cfg, fg_color="transparent"); r.pack(fill="x", padx=16, pady=4)
                ctk.CTkLabel(r, text=label, font=F["sub"], text_color=C["text"],
                             width=140, anchor="e").pack(side="right")
                cb = ctk.CTkComboBox(r, values=col_opts, width=220, height=36,
                                     fg_color=C["card2"], border_color=C["border"],
                                     button_color=C["teal"], dropdown_fg_color=C["card"],
                                     text_color=C["text"], font=F["entry"])
                cb.pack(side="right", padx=8)
                # تخمين تلقائي
                for h in headers:
                    if default_search.lower() in str(h).lower():
                        cb.set(h); break
                else:
                    cb.set(col_opts[0])
                return cb

            cb_name  = make_row("عمود الاسم  *",        "اسم")
            cb_phone = make_row("عمود الهاتف",           "هاتف")
            cb_fees  = make_row("عمود الرسوم",           "رسوم")
            cb_class = make_row("عمود الفصل",            "فصل")

            # معاينة أول 5 صفوف
            prev = ctk.CTkFrame(win, fg_color=C["card"], corner_radius=16)
            prev.pack(fill="both", expand=True, padx=24, pady=8)
            ctk.CTkLabel(prev, text="معاينة أول 5 صفوف:",
                         font=F["sub"], text_color=C["muted"]).pack(anchor="e", padx=16, pady=(10, 4))
            pt = self._styled_tree(prev, headers[:6], height=5)
            for row in rows_raw[1:6]:
                pt.insert("", "end", values=[str(c or "") for c in row[:6]])

            result = {"done": False}

            def do_import():
                name_col = cb_name.get()
                if name_col == "— لا يوجد —":
                    messagebox.showwarning("تنبيه", "يجب تحديد عمود الاسم على الأقل"); return

                def col_idx(cb):
                    v = cb.get()
                    if v == "— لا يوجد —": return None
                    try: return headers.index(v)
                    except: return None

                ni = col_idx(cb_name)
                pi = col_idx(cb_phone)
                fi = col_idx(cb_fees)
                ci = col_idx(cb_class)

                added = skipped = 0
                con2 = connect(); cur2 = con2.cursor()
                # الفصول المتاحة
                cur2.execute("SELECT id, class_name||' '||section FROM classes")
                class_map = {r[1].strip(): r[0] for r in cur2.fetchall()}

                for row in rows_raw[1:]:
                    name = str(row[ni] or "").strip() if ni is not None else ""
                    if not name: skipped += 1; continue
                    phone = str(row[pi] or "").strip() if pi is not None else ""
                    fees_raw = row[fi] if fi is not None else 0
                    try: fees = float(fees_raw or 0)
                    except: fees = 0.0
                    class_str = str(row[ci] or "").strip() if ci is not None else ""
                    cid = class_map.get(class_str)

                    try:
                        cur2.execute("""INSERT INTO students(name,grade,parent_phone,parent_code,total_fees,paid_fees,class_id)
                                        VALUES(?,?,?,?,?,0,?)""",
                                     (name, class_str or "—", normalize_phone(phone), "", fees, cid))
                        new_id = cur2.lastrowid
                        cur2.execute("UPDATE students SET parent_code=? WHERE id=?",
                                     (f"ARK-{1000+new_id}", new_id))
                        added += 1
                    except Exception:
                        skipped += 1

                con2.commit(); con2.close()
                result["done"] = True
                messagebox.showinfo("تم الاستيراد",
                    f"✅  تم استيراد {added} طالب بنجاح\n⚠️  تم تجاهل {skipped} سجل")
                show_toast(self, f"📥  تم استيراد {added} طالب من Excel")
                win.destroy()
                self.students_screen()

            bf = ctk.CTkFrame(win, fg_color="transparent"); bf.pack(pady=(4, 16))
            ctk.CTkButton(bf, text="📥  استيراد الآن", command=do_import,
                fg_color=C["teal"], hover_color=C["teal2"],
                text_color=C["white"], font=F["btn"],
                height=44, width=200, corner_radius=12).pack(side="right", padx=8)
            ctk.CTkButton(bf, text="إلغاء", command=win.destroy,
                fg_color=C["card2"], hover_color=C["red2"],
                text_color=C["muted"], font=F["btn"],
                height=44, width=120, corner_radius=12).pack(side="right")

        acts = ctk.CTkFrame(self.content, fg_color=C["bg"]); acts.pack(fill="x",padx=28,pady=(0,2))
        self.btn(acts,"إضافة طالب",add,C["teal"],120)
        self.btn(acts,"مسح",clear_f,C["card2"],80)
        self.btn(acts,"تعديل",load_edit,"#F59E0B",90)
        self.btn(acts,"حفظ التعديل",save_edit,C["teal2"],120)
        self.btn(acts,"نسخ كود ولي الأمر",copy_code,C["gold"],160)
        self.btn(acts,"حذف",delete_s,C["red"],80)

        # صف الأزرار الذكية
        acts2 = ctk.CTkFrame(self.content, fg_color=C["bg"]); acts2.pack(fill="x",padx=28,pady=(0,6))
        ctk.CTkLabel(acts2, text="📲  واتساب:", font=F["sub"],
                     text_color=C["muted"]).pack(side="right", padx=(0,6))
        self.btn(acts2, "💬  رسوم متأخرة",  whatsapp_selected,  "#25D366", 140)
        self.btn(acts2, "🔴  إشعار غياب",   whatsapp_absent,    "#128C7E", 130)
        self.btn(acts2, "📢  جميع المتأخرين", whatsapp_bulk_fees, "#075E54", 160)
        ctk.CTkFrame(acts2, width=2, height=36, fg_color=C["border"]).pack(side="right", padx=10)
        self.btn(acts2, "📥  استيراد Excel", import_excel,       C["gold"],  150)

        t = self.tree(["ID","الاسم","الفصل","الهاتف","الرسوم","كود ولي الأمر","المدفوع","المتبقي"])
        t.bind("<Double-1>", lambda e: load_edit())

        con=connect(); cur=con.cursor()
        cur.execute("SELECT id,name,grade,parent_phone,total_fees,parent_code,paid_fees FROM students ORDER BY id DESC")
        for r in cur.fetchall():
            t.insert("","end",values=(r[0],r[1],r[2],r[3],r[4],r[5] or "",r[6],round(r[4]-r[6],2)))
        con.close()

    # ══════════════════════════════════
    #  المعلمون
    # ══════════════════════════════════
    def teachers_screen(self):
        self.clear_content()
        self.page_title("المعلمون","إدارة بيانات المعلمين")
        form = self.form_frame()
        nm=self.input(form,"الاسم",175); sb=self.input(form,"المادة",140)
        ph=self.input(form,"الهاتف",140); sl=self.input(form,"الراتب",120)
        eid={"v":None}

        def clear_f():
            eid["v"]=None
            for e in [nm,sb,ph,sl]: e.delete(0,"end")

        def add():
            if not nm.get().strip(): messagebox.showwarning("تنبيه","اكتب اسم المعلم"); return
            con=connect(); cur=con.cursor()
            cur.execute("INSERT INTO teachers(name,subject,phone,salary) VALUES(?,?,?,?)",
                        (nm.get().strip(),sb.get().strip(),ph.get().strip(),float(sl.get() or 0)))
            con.commit(); con.close(); self.teachers_screen()

        def load_edit():
            sel=t.focus()
            if not sel: return
            v=t.item(sel,"values")
            eid["v"]=int(v[0])
            for e,val in zip([nm,sb,ph,sl],[v[1],v[2],v[3],v[4]]):
                e.delete(0,"end"); e.insert(0,val)

        def save_edit():
            if not eid["v"]: return
            con=connect(); cur=con.cursor()
            cur.execute("UPDATE teachers SET name=?,subject=?,phone=?,salary=? WHERE id=?",
                        (nm.get().strip(),sb.get().strip(),ph.get().strip(),float(sl.get() or 0),eid["v"]))
            con.commit(); con.close(); self.teachers_screen()

        def delete_t():
            sel=t.focus()
            if not sel: return
            v=t.item(sel,"values")
            if not messagebox.askyesno("تأكيد",f"حذف المعلم {v[1]}؟"): return
            con=connect(); cur=con.cursor()
            cur.execute("DELETE FROM teachers WHERE id=?",(int(v[0]),))
            con.commit(); con.close(); self.teachers_screen()

        acts=ctk.CTkFrame(self.content,fg_color=C["bg"]); acts.pack(fill="x",padx=28,pady=(0,2))
        self.btn(acts,"إضافة",add,C["teal"],100)
        self.btn(acts,"مسح",clear_f,C["card2"],80)
        self.btn(acts,"تعديل",load_edit,"#F59E0B",90)
        self.btn(acts,"حفظ",save_edit,C["teal2"],90)
        self.btn(acts,"حذف",delete_t,C["red"],80)

        t=self.tree(["ID","الاسم","المادة","الهاتف","الراتب"])
        t.bind("<Double-1>",lambda e: load_edit())
        con=connect(); cur=con.cursor()
        cur.execute("SELECT id,name,subject,phone,salary FROM teachers ORDER BY id DESC")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  تكليف المعلمين
    # ══════════════════════════════════
    def teacher_assign_screen(self):
        self.clear_content()
        self.page_title("تكليف المعلمين","ربط كل معلم بفصوله ومواده")
        form=self.form_frame()
        con=connect(); cur=con.cursor()
        cur.execute("SELECT username FROM users WHERE role='teacher' ORDER BY username")
        tusers=[r[0] for r in cur.fetchall()]
        cur.execute("SELECT id,class_name,section FROM classes ORDER BY id")
        class_rows=cur.fetchall()
        cur.execute("""SELECT subjects.id,subjects.subject_name,IFNULL(classes.class_name||' '||classes.section,'')
                       FROM subjects LEFT JOIN classes ON subjects.class_id=classes.id ORDER BY subjects.subject_name""")
        sub_rows=cur.fetchall()
        con.close()

        cmap2={f"{r[1]} {r[2]}":r[0] for r in class_rows}
        smap2={f"{r[1]} / {r[2]}":r[0] for r in sub_rows}

        ubox=self.combo(form,tusers or ["لا يوجد"],180)
        clbox=self.combo(form,list(cmap2.keys()),220)
        sbox=self.combo(form,list(smap2.keys()),260)

        def assign():
            u=ubox.get(); cid=cmap2.get(clbox.get()); sid2=smap2.get(sbox.get())
            if not cid or not sid2: return
            con=connect(); cur=con.cursor()
            cur.execute("INSERT OR IGNORE INTO teacher_assignments(username,class_id,subject_id) VALUES(?,?,?)",(u,cid,sid2))
            con.commit(); con.close(); refresh()

        def remove_assign():
            sel=t.focus()
            if not sel: return
            aid=int(t.item(sel,"values")[0])
            con=connect(); cur=con.cursor()
            cur.execute("DELETE FROM teacher_assignments WHERE id=?",(aid,))
            con.commit(); con.close(); refresh()

        self.btn(form,"تكليف",assign,C["teal"],100)
        self.btn(form,"إزالة التكليف المحدد",remove_assign,C["red"],180)

        t=self.tree(["ID","المعلم","الفصل","المادة"])

        def refresh():
            for i in t.get_children(): t.delete(i)
            con=connect(); cur=con.cursor()
            cur.execute("""SELECT ta.id,ta.username,
                           IFNULL(c.class_name||' '||c.section,'-'),
                           IFNULL(s.subject_name,'-')
                           FROM teacher_assignments ta
                           LEFT JOIN classes c ON ta.class_id=c.id
                           LEFT JOIN subjects s ON ta.subject_id=s.id
                           ORDER BY ta.username,c.id""")
            for row in cur.fetchall(): t.insert("","end",values=row)
            con.close()
        refresh()

    # ══════════════════════════════════
    #  حضور الطلاب — جديد
    # ══════════════════════════════════
    def attendance_screen(self):
        self.clear_content()
        self.page_title("تسجيل حضور الطلاب",
                        "اختر الفصل — حدد الغائبين فقط — الباقون حاضرون تلقائياً")

        classes = self.get_visible_classes()
        cmap = {f"{r[1]} {r[2]}": r[0] for r in classes}
        today = str(date.today())

        top = self.form_frame()
        cbox = self.combo(top, list(cmap.keys()), 240)
        day_e = self.input(top,"التاريخ",130); day_e.insert(0, today)

        # إطار يحتوي قائمة الطلاب
        list_frame = ctk.CTkFrame(self.content, fg_color=C["card"], corner_radius=16)
        list_frame.pack(fill="both", expand=True, padx=28, pady=6)
        ctk.CTkLabel(list_frame, text="اختر الفصل لعرض الطلاب",
                     font=F["sub"], text_color=C["muted"]).pack(pady=20)

        student_vars = {}  # sid -> BooleanVar (True=غائب)

        def load_students(event=None):
            for w in list_frame.winfo_children(): w.destroy()
            cid = cmap.get(cbox.get())
            if not cid: return
            con = connect(); cur = con.cursor()
            cur.execute("SELECT id,name FROM students WHERE class_id=? ORDER BY name",(cid,))
            rows = cur.fetchall(); con.close()

            student_vars.clear()
            ctk.CTkLabel(list_frame,
                text=f"طلاب فصل: {cbox.get()}  —  اختر الغائبين فقط",
                font=F["head"], text_color=C["gold"]).pack(anchor="e",padx=20,pady=(14,8))

            sf = ctk.CTkScrollableFrame(list_frame, fg_color="transparent", height=380)
            sf.pack(fill="both", expand=True, padx=14, pady=(0,10))

            for sid, sname in rows:
                var = tk.BooleanVar(value=False)
                student_vars[sid] = (sname, var)
                row_f = ctk.CTkFrame(sf, fg_color=C["card2"], corner_radius=10)
                row_f.pack(fill="x", padx=4, pady=3)
                ctk.CTkCheckBox(row_f, text=sname, variable=var,
                    font=("Tahoma",13), text_color=C["text"],
                    fg_color=C["red"], hover_color=C["red2"],
                    checkmark_color=C["white"]).pack(anchor="e",padx=16,pady=10)

            if not rows:
                ctk.CTkLabel(list_frame, text="لا يوجد طلاب في هذا الفصل",
                             font=F["sub"], text_color=C["muted"]).pack(pady=20)

        cbox.configure(command=load_students)

        def save_attendance():
            if not student_vars:
                messagebox.showwarning("تنبيه","اختر الفصل أولاً"); return
            day = day_e.get().strip() or today
            if not validate_date(day):
                messagebox.showerror("خطأ","التاريخ غير صحيح. استخدم صيغة YYYY-MM-DD مثال: 2026-09-15"); return
            con = connect(); cur = con.cursor()
            # حذف سجل اليوم لنفس الفصل قبل الحفظ
            cid = cmap.get(cbox.get())
            cur.execute("""DELETE FROM attendance
                           WHERE person_type='طالب' AND day=? AND person_id IN
                           (SELECT id FROM students WHERE class_id=?)""",(day,cid))
            saved = 0
            for sid,(sname,var) in student_vars.items():
                status = "غائب" if var.get() else "حاضر"
                cur.execute("INSERT INTO attendance(person_type,person_id,name,status,day) VALUES(?,?,?,?,?)",
                            ("طالب",sid,sname,status,day))
                if status == "غائب":
                    push_notification(sid,"تسجيل غياب",f"تم تسجيل غيابك بتاريخ {day}")
                saved += 1
            con.commit(); con.close()
            messagebox.showinfo("تم",f"تم حفظ حضور {saved} طالب ليوم {day} ✅")
            show_toast(self, f"✅  تم حفظ الحضور  |  {saved} طالب")

        self.btn(top, "💾  حفظ الحضور", save_attendance, C["teal"], 150)

    # ══════════════════════════════════
    #  سجل حضور الطلاب
    # ══════════════════════════════════
    def attendance_log_screen(self):
        self.clear_content()
        self.page_title("سجل حضور الطلاب","عرض وتصفية سجلات الحضور")
        form=self.form_frame()
        day_e=self.input(form,"التاريخ",130); day_e.insert(0,str(date.today()))
        classes=self.get_visible_classes()
        cmap={f"{r[1]} {r[2]}":r[0] for r in classes}
        cbox=self.combo(form,["الكل"]+list(cmap.keys()),200)

        def load():
            for i in t.get_children(): t.delete(i)
            day=day_e.get().strip()
            con=connect(); cur=con.cursor()
            sel=cbox.get()
            if sel=="الكل":
                cur.execute("""SELECT a.id,s.name,IFNULL(c.class_name||' '||c.section,s.grade),
                               a.status,a.day FROM attendance a
                               JOIN students s ON a.person_id=s.id
                               LEFT JOIN classes c ON s.class_id=c.id
                               WHERE a.person_type='طالب' AND a.day=?
                               ORDER BY a.id DESC""",(day,))
            else:
                cid=cmap.get(sel)
                cur.execute("""SELECT a.id,s.name,IFNULL(c.class_name||' '||c.section,s.grade),
                               a.status,a.day FROM attendance a
                               JOIN students s ON a.person_id=s.id
                               LEFT JOIN classes c ON s.class_id=c.id
                               WHERE a.person_type='طالب' AND a.day=? AND s.class_id=?
                               ORDER BY a.id DESC""",(day,cid))
            for row in cur.fetchall():
                tag="fail" if row[3]=="غائب" else "pass"
                t.insert("","end",values=row,tags=(tag,))
            con.close()

        self.btn(form,"عرض",load,C["gold"],90)
        t=self.tree(["ID","الطالب","الفصل","الحالة","التاريخ"])
        load()

    # ══════════════════════════════════
    #  حضور المعلمين
    # ══════════════════════════════════
    def teacher_att_screen(self):
        self.clear_content()
        self.page_title("حضور المعلمين","تسجيل حضور وغياب المعلمين")
        today=str(date.today())
        form=self.form_frame()
        day_e=self.input(form,"التاريخ",130); day_e.insert(0,today)

        list_frame=ctk.CTkFrame(self.content,fg_color=C["card"],corner_radius=16)
        list_frame.pack(fill="both",expand=True,padx=28,pady=6)

        teacher_vars={}
        con=connect(); cur=con.cursor()
        cur.execute("SELECT id,name FROM teachers ORDER BY name")
        teachers=cur.fetchall(); con.close()

        ctk.CTkLabel(list_frame,text="اختر حالة كل معلم:",
                     font=F["head"],text_color=C["gold"]).pack(anchor="e",padx=20,pady=(14,8))
        sf=ctk.CTkScrollableFrame(list_frame,fg_color="transparent",height=380)
        sf.pack(fill="both",expand=True,padx=14,pady=(0,10))

        STATUS_OPTS=["حاضر","غائب","متأخر","إجازة"]
        for tid,tname in teachers:
            row_f=ctk.CTkFrame(sf,fg_color=C["card2"],corner_radius=10)
            row_f.pack(fill="x",padx=4,pady=3)
            ctk.CTkLabel(row_f,text=tname,font=("Tahoma",13,"bold"),
                         text_color=C["text"]).pack(side="right",padx=16,pady=10)
            var=tk.StringVar(value="حاضر")
            teacher_vars[tid]=(tname,var)
            for s in STATUS_OPTS:
                ctk.CTkRadioButton(row_f,text=s,variable=var,value=s,
                    font=("Tahoma",12),text_color=C["muted"],
                    fg_color=C["gold"],hover_color=C["gold2"]).pack(side="left",padx=10,pady=10)

        def save():
            day=day_e.get().strip() or today
            if not validate_date(day):
                messagebox.showerror("خطأ","التاريخ غير صحيح. استخدم صيغة YYYY-MM-DD"); return
            con=connect(); cur=con.cursor()
            cur.execute("DELETE FROM attendance WHERE person_type='معلم' AND day=?",(day,))
            for tid,(tname,var) in teacher_vars.items():
                cur.execute("INSERT INTO attendance(person_type,person_id,name,status,day) VALUES(?,?,?,?,?)",
                            ("معلم",tid,tname,var.get(),day))
            con.commit(); con.close()
            messagebox.showinfo("تم",f"تم حفظ حضور {len(teacher_vars)} معلم ✅")

        bf=ctk.CTkFrame(self.content,fg_color=C["bg"]); bf.pack(fill="x",padx=28,pady=4)
        self.btn(bf,"💾  حفظ حضور المعلمين",save,C["teal"],200)

    # ══════════════════════════════════
    #  الدرجات — نظام الصف/المادة/صلاحية المعلم
    # ══════════════════════════════════
    def grades_screen(self):
        self.clear_content()
        self.page_title(
            "الدرجات",
            "كل صف يعرض مواده فقط، والمعلم يرى مادته وفصوله فقط — اضغط على الطالب لإدخال درجته"
        )

        classes = self.get_visible_classes()
        cmap = {f"{r[1]} {r[2]}".strip(): r[0] for r in classes}
        top = self.form_frame()
        cbox = self.combo(top, list(cmap.keys()), 260)

        info_var = tk.StringVar(value="اختر الفصل ثم اضغط على اسم الطالب")
        ctk.CTkLabel(top, textvariable=info_var, font=F["sub"], text_color=C["muted"]).pack(side="right", padx=12)

        main = ctk.CTkFrame(self.content, fg_color=C["bg"])
        main.pack(fill="both", expand=True, padx=28, pady=8)

        left = ctk.CTkFrame(main, fg_color=C["card"], corner_radius=18, width=340,
                            border_width=1, border_color=C["border"])
        left.pack(side="right", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        ctk.CTkFrame(left, height=4, fg_color=C["gold"]).pack(fill="x")
        ctk.CTkLabel(left, text="طلاب الفصل", font=F["head"], text_color=C["gold"]).pack(anchor="e", padx=18, pady=(14, 4))
        ctk.CTkLabel(left, text="اضغط على الطالب لفتح نافذة الدرجات", font=F["small"], text_color=C["muted"]).pack(anchor="e", padx=18, pady=(0, 8))
        search_e = ctk.CTkEntry(left, width=290, height=38, placeholder_text="بحث عن طالب...",
                                justify="right", font=F["entry"], fg_color=C["card2"],
                                border_color=C["border"], text_color=C["text"],
                                placeholder_text_color=C["muted"], corner_radius=10)
        search_e.pack(fill="x", padx=14, pady=(0, 8))
        students_box = ctk.CTkScrollableFrame(left, fg_color="transparent")
        students_box.pack(fill="both", expand=True, padx=8, pady=(0, 10))

        right = ctk.CTkFrame(main, fg_color=C["card"], corner_radius=18,
                             border_width=1, border_color=C["border"])
        right.pack(side="right", fill="both", expand=True)
        ctk.CTkFrame(right, height=4, fg_color=C["teal"]).pack(fill="x")
        ctk.CTkLabel(right, text="سجل درجات الفصل", font=F["head"], text_color=C["teal"]).pack(anchor="e", padx=18, pady=(14, 6))
        grades_tree = self._styled_tree(right, ["ID", "الطالب", "المادة", "أعمال", "نصف", "نهائي", "المجموع", "التقدير", "المعلم", "التاريخ"], height=16)

        def get_subjects_for_class(class_id):
            con = connect(); cur = con.cursor()
            cur.execute("SELECT id,subject_name FROM subjects WHERE class_id=? ORDER BY id", (class_id,))
            rows = cur.fetchall(); con.close()
            if self.current_role == "teacher":
                _, allowed_subjects = self.get_teacher_scope()
                rows = [r for r in rows if r[0] in allowed_subjects]
            return rows

        def load_class_grades():
            for i in grades_tree.get_children(): grades_tree.delete(i)
            cid = cmap.get(cbox.get())
            if not cid: return
            subs = get_subjects_for_class(cid)
            sub_ids = [s[0] for s in subs]
            if not sub_ids:
                info_var.set("لا توجد مواد مسموحة لهذا المستخدم في هذا الفصل")
                return
            ph = ",".join("?" * len(sub_ids))
            con = connect(); cur = con.cursor()
            cur.execute(f"""SELECT g.id, s.name, sub.subject_name, g.work_score, g.mid_score,
                                  g.final_score, g.total_score, g.grade_text, IFNULL(g.author,''), g.exam_date
                           FROM grades g
                           JOIN students s ON g.student_id=s.id
                           JOIN subjects sub ON g.subject_id=sub.id
                           WHERE s.class_id=? AND g.subject_id IN ({ph})
                           ORDER BY s.name, sub.subject_name""", [cid] + sub_ids)
            for row in cur.fetchall():
                tag = "fail" if str(row[7]) == "راسب" else "pass"
                grades_tree.insert("", "end", values=row, tags=(tag,))
            grades_tree.tag_configure("fail", foreground=C["red"])
            grades_tree.tag_configure("pass", foreground=C["green"])
            con.close()

        def load_students(event=None):
            for w in students_box.winfo_children(): w.destroy()
            cid = cmap.get(cbox.get())
            if not cid: return
            subs = get_subjects_for_class(cid)
            if not subs:
                ctk.CTkLabel(students_box, text="لا توجد مواد مكلف بها لهذا الفصل", font=F["sub"], text_color=C["red"]).pack(anchor="e", padx=10, pady=20)
                info_var.set("لا توجد مادة مرتبطة بهذا الفصل أو بصلاحية المعلم")
                load_class_grades()
                return
            q = search_e.get().strip()
            con = connect(); cur = con.cursor()
            if q:
                cur.execute("SELECT id,name,grade FROM students WHERE class_id=? AND name LIKE ? ORDER BY name", (cid, f"%{q}%"))
            else:
                cur.execute("SELECT id,name,grade FROM students WHERE class_id=? ORDER BY name", (cid,))
            rows = cur.fetchall(); con.close()
            info_var.set(f"الفصل: {cbox.get()} | المواد المتاحة: {len(subs)} | الطلاب: {len(rows)}")
            for sid, sname, grade_name in rows:
                b = ctk.CTkButton(students_box, text=f"👨‍🎓  {sname}",
                                  fg_color=C["card2"], hover_color=C["gold_dim"],
                                  text_color=C["text"], font=("Tahoma", 13, "bold"),
                                  anchor="e", height=42, corner_radius=12,
                                  command=lambda s=sid, n=sname, g=grade_name: open_grade_popup(s, n, g))
                b.pack(fill="x", padx=4, pady=3)
                b.bind("<Enter>", lambda e, btn=b: btn.configure(fg_color=C["gold_dim"], text_color=C["gold"]))
                b.bind("<Leave>", lambda e, btn=b: btn.configure(fg_color=C["card2"], text_color=C["text"]))
            load_class_grades()

        def open_grade_popup(student_id, student_name, grade_name):
            cid = cmap.get(cbox.get())
            subjects = get_subjects_for_class(cid)
            if not subjects:
                messagebox.showwarning("صلاحيات", "لا توجد مادة مسموحة لك في هذا الفصل")
                return

            win = ctk.CTkToplevel(self)
            win.title(f"درجات الطالب - {student_name}")
            win.geometry("920x620")
            win.transient(self)
            win.grab_set()
            win.configure(fg_color=C["bg"])

            header = ctk.CTkFrame(win, fg_color=C["topbar"], corner_radius=0, height=76)
            header.pack(fill="x"); header.pack_propagate(False)
            ctk.CTkLabel(header, text=f"درجات الطالب: {student_name}", font=("Tahoma", 20, "bold"), text_color=C["gold"]).pack(anchor="e", padx=22, pady=(12, 2))
            ctk.CTkLabel(header, text=f"الفصل: {grade_name or cbox.get()}   |   الإدخال بواسطة: {self.current_username or 'الإدارة'}",
                         font=F["sub"], text_color=C["white"]).pack(anchor="e", padx=22)

            body = ctk.CTkScrollableFrame(win, fg_color=C["bg"])
            body.pack(fill="both", expand=True, padx=18, pady=12)

            # رأس الجدول
            head = ctk.CTkFrame(body, fg_color=C["sidebar"], corner_radius=10)
            head.pack(fill="x", padx=4, pady=(0, 6))
            for txt, w in [("المادة", 220), ("أعمال /20", 110), ("نصف /30", 110), ("نهائي /50", 110), ("المجموع", 110), ("التقدير", 110), ("حذف", 80)]:
                ctk.CTkLabel(head, text=txt, width=w, font=F["treeh"], text_color=C["gold"]).pack(side="right", padx=2, pady=10)

            con = connect(); cur = con.cursor()
            cur.execute("""SELECT subject_id, work_score, mid_score, final_score, total_score, grade_text, id
                           FROM grades WHERE student_id=?""", (student_id,))
            saved = {r[0]: r for r in cur.fetchall()}
            con.close()

            entries = {}
            delete_flags = {}

            def safe_float(entry):
                try: return float(entry.get() or 0)
                except: return 0.0

            def validate_limits(w, m, f):
                if w < 0 or w > 20: return False, "أعمال السنة يجب أن تكون من 0 إلى 20"
                if m < 0 or m > 30: return False, "امتحان النصف يجب أن يكون من 0 إلى 30"
                if f < 0 or f > 50: return False, "النهائي يجب أن يكون من 0 إلى 50"
                return True, ""

            for idx, (sub_id, sub_name) in enumerate(subjects):
                row = ctk.CTkFrame(body, fg_color=(C["row_even"] if idx % 2 else C["row_odd"]), corner_radius=10,
                                   border_width=1, border_color=C["border"])
                row.pack(fill="x", padx=4, pady=3)

                ctk.CTkLabel(row, text=sub_name, width=220, anchor="e", font=("Tahoma", 12, "bold"), text_color=C["text"]).pack(side="right", padx=2, pady=8)

                def make_e(ph, width=110):
                    e = ctk.CTkEntry(row, width=width, height=34, placeholder_text=ph, justify="center",
                                     font=F["entry"], fg_color=C["card2"], border_color=C["border"],
                                     text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=8)
                    e.pack(side="right", padx=2, pady=8)
                    return e

                work_e = make_e("0-20")
                mid_e = make_e("0-30")
                final_e = make_e("0-50")
                total_lbl = ctk.CTkLabel(row, text="0.0", width=110, font=("Tahoma", 12, "bold"), text_color=C["muted"])
                total_lbl.pack(side="right", padx=2, pady=8)
                grade_lbl = ctk.CTkLabel(row, text="—", width=110, font=("Tahoma", 12, "bold"), text_color=C["muted"])
                grade_lbl.pack(side="right", padx=2, pady=8)
                del_var = tk.BooleanVar(value=False)
                ctk.CTkCheckBox(row, text="", variable=del_var, width=80, fg_color=C["red"], hover_color=C["red2"]).pack(side="right", padx=2, pady=8)

                if sub_id in saved:
                    sv = saved[sub_id]
                    work_e.insert(0, str(sv[1] or 0))
                    mid_e.insert(0, str(sv[2] or 0))
                    final_e.insert(0, str(sv[3] or 0))

                def recalc(_event=None, we=work_e, me=mid_e, fe=final_e, tl=total_lbl, gl=grade_lbl):
                    w = safe_float(we); m = safe_float(me); f = safe_float(fe)
                    total = w + m + f
                    gtxt = grade_label(total)
                    ok, _ = validate_limits(w, m, f)
                    color = C["green"] if (gtxt != "راسب" and ok) else C["red"]
                    tl.configure(text=f"{total:.1f}", text_color=color)
                    gl.configure(text=gtxt, text_color=color)

                for e in (work_e, mid_e, final_e): e.bind("<KeyRelease>", recalc)
                recalc()
                entries[sub_id] = (sub_name, work_e, mid_e, final_e, total_lbl, grade_lbl)
                delete_flags[sub_id] = del_var

            footer = ctk.CTkFrame(win, fg_color=C["bg"])
            footer.pack(fill="x", padx=18, pady=(0, 14))

            def save_all():
                con = connect(); cur = con.cursor()
                changed = 0; deleted = 0
                for sub_id, (sub_name, we, me, fe, tl, gl) in entries.items():
                    if delete_flags[sub_id].get():
                        if sub_id in saved:
                            if not messagebox.askyesno("حذف درجة", f"سيتم حذف درجة مادة {sub_name} نهائياً. هل أنت متأكد؟"):
                                continue
                            cur.execute("DELETE FROM grades WHERE id=?", (saved[sub_id][6],))
                            deleted += 1
                        continue
                    w = safe_float(we); m = safe_float(me); f = safe_float(fe)
                    ok, msg = validate_limits(w, m, f)
                    if not ok:
                        messagebox.showerror("خطأ في الدرجات", f"{sub_name}: {msg}")
                        con.close(); return
                    total = w + m + f
                    gtxt = grade_label(total)
                    if sub_id in saved:
                        # تعديل محفوظ
                        if not messagebox.askyesno("تعديل درجة", f"هل أنت متأكد من تعديل درجة مادة {sub_name}؟"):
                            continue
                        cur.execute("""UPDATE grades SET work_score=?, mid_score=?, final_score=?, total_score=?,
                                       grade_text=?, exam_date=?, author=? WHERE id=?""",
                                    (w, m, f, total, gtxt, str(date.today()), self.current_username or "", saved[sub_id][6]))
                    else:
                        # لا تحفظ صفاً فارغاً بالكامل إلا إذا أدخل المعلم درجة
                        if w == 0 and m == 0 and f == 0:
                            continue
                        cur.execute("""INSERT INTO grades(student_id, subject_id, work_score, mid_score, final_score,
                                       total_score, grade_text, exam_date, author)
                                       VALUES(?,?,?,?,?,?,?,?,?)""",
                                    (student_id, sub_id, w, m, f, total, gtxt, str(date.today()), self.current_username or ""))
                    changed += 1
                    push_notification(student_id, "درجة جديدة", f"تم تسجيل/تعديل درجة {sub_name}: {total:.1f} - {gtxt}")
                con.commit(); con.close()
                messagebox.showinfo("تم", f"تم الحفظ ✅\nتعديلات: {changed}\nحذف: {deleted}")
                show_toast(self, f"✅  تم حفظ الدرجات — تعديلات: {changed}")
                win.destroy()
                load_class_grades()

            def print_pdf():
                data = []
                for sub_id, (sub_name, we, me, fe, tl, gl) in entries.items():
                    w = safe_float(we); m = safe_float(me); f = safe_float(fe)
                    total = w + m + f
                    data.append([sub_name, w, m, f, total, grade_label(total)])
                path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
                                                    initialfile=f"كشف_درجات_{student_name}.pdf")
                if path:
                    export_grades_pdf(student_name, grade_name or cbox.get(), data, path)
                    messagebox.showinfo("تم", f"تم حفظ الكشف:\n{path}")

            self.btn(footer, "💾  حفظ كل الدرجات", save_all, C["teal"], 190)
            self.btn(footer, "📄  طباعة PDF", print_pdf, C["gold"], 150)
            self.btn(footer, "إغلاق", win.destroy, C["card2"], 110)

        cbox.configure(command=load_students)
        search_e.bind("<KeyRelease>", load_students)
        load_students()

    # ══════════════════════════════════
    #  ملاحظات الطلاب
    # ══════════════════════════════════
    def student_notes_screen(self):
        self.clear_content()
        self.page_title("ملاحظات الطلاب","إضافة وعرض ملاحظات المدرسة على الطلاب")
        form=self.form_frame()
        sid=self.input(form,"ID الطالب",120)
        note=ctk.CTkEntry(form, width=380, height=40,
            placeholder_text="الملاحظة...", justify="right",
            font=F["entry"], fg_color=C["card2"], border_color=C["border"],
            text_color=C["text"], placeholder_text_color=C["muted"], corner_radius=10)
        note.pack(side="right",padx=5,pady=5)

        def save_note():
            try:
                s=int(sid.get()); txt=note.get().strip()
                if not txt: messagebox.showwarning("تنبيه","اكتب الملاحظة"); return
                if not self.can_access_student(s):
                    messagebox.showerror("صلاحيات","لا يمكنك إضافة ملاحظة لطالب خارج فصولك"); return
                con=connect(); cur=con.cursor()
                cur.execute("SELECT name FROM students WHERE id=?",(s,))
                row=cur.fetchone()
                if not row: messagebox.showerror("خطأ","الطالب غير موجود"); con.close(); return
                cur.execute("INSERT INTO student_notes(student_id,note_text,note_date,author) VALUES(?,?,?,?)",
                            (s,txt,str(date.today()),self.current_username or ""))
                con.commit(); con.close()
                push_notification(s,"ملاحظة من المدرسة",txt)
                self.student_notes_screen()
            except Exception as e: messagebox.showerror("خطأ",str(e))

        self.btn(form,"إضافة ملاحظة",save_note,C["teal"],140)
        t=self.tree(["ID","ID الطالب","اسم الطالب","الملاحظة","التاريخ","الكاتب"])
        con=connect(); cur=con.cursor()
        if self.current_role=="teacher":
            cids,_=self.get_teacher_scope()
            if cids:
                ph=",".join("?"*len(cids))
                cur.execute(f"""SELECT sn.id,sn.student_id,s.name,sn.note_text,sn.note_date,IFNULL(sn.author,'')
                               FROM student_notes sn JOIN students s ON sn.student_id=s.id
                               WHERE s.class_id IN ({ph}) ORDER BY sn.id DESC""",tuple(cids))
            else: cur.execute("SELECT 1 WHERE 0")
        else:
            cur.execute("""SELECT sn.id,sn.student_id,s.name,sn.note_text,sn.note_date,IFNULL(sn.author,'')
                           FROM student_notes sn JOIN students s ON sn.student_id=s.id
                           ORDER BY sn.id DESC""")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  الرسوم
    # ══════════════════════════════════
    def payments_screen(self):
        self.clear_content()
        self.page_title("الرسوم والدفع","تسجيل دفعات الطلاب بالدينار الليبي")
        form=self.form_frame()
        sid=self.input(form,"ID الطالب",120)
        amt=self.input(form,"المبلغ",140)

        def save():
            try:
                s=int(sid.get()); v=float(amt.get())
                con=connect(); cur=con.cursor()
                cur.execute("SELECT total_fees,paid_fees,name FROM students WHERE id=?",(s,))
                row=cur.fetchone()
                if not row: messagebox.showerror("خطأ","الطالب غير موجود"); con.close(); return
                tot,pd,nm=row
                if pd+v > tot:
                    messagebox.showerror("خطأ","المبلغ أكبر من المتبقي"); con.close(); return
                cur.execute("INSERT INTO payments(student_id,amount,pay_date,note) VALUES(?,?,?,?)",
                            (s,v,str(date.today()),"دفعة رسوم"))
                cur.execute("UPDATE students SET paid_fees=paid_fees+? WHERE id=?",(v,s))
                con.commit(); con.close()
                messagebox.showinfo("تم",f"تم تسجيل دفعة {v:.2f} د.ل للطالب: {nm}")
                self.payments_screen()
            except Exception as e: messagebox.showerror("خطأ",str(e))

        def send_whatsapp_reminder():
            """إرسال تذكير رسوم عبر واتساب للطالب المحدد"""
            sel = t.focus()
            if not sel:
                messagebox.showwarning("تنبيه", "اختر سجل دفعة أولاً"); return
            v = t.item(sel, "values")
            student_id = int(v[1])
            con2 = connect(); cur2 = con2.cursor()
            cur2.execute("SELECT name, parent_phone, total_fees, paid_fees FROM students WHERE id=?", (student_id,))
            row = cur2.fetchone(); con2.close()
            if not row: return
            name, phone, total, paid = row
            remaining = total - paid
            phone = normalize_phone(phone or "")
            if not phone or phone == "0":
                messagebox.showwarning("تنبيه", f"لا يوجد رقم هاتف للطالب: {name}"); return
            if phone.startswith("0"): phone = "218" + phone[1:]
            msg = f"السلام عليكم ولي أمر الطالب {name}،\nتم تسجيل دفعتكم بمبلغ {float(v[3]):.0f} د.ل بتاريخ {v[4]}.\nالمتبقي: {remaining:.0f} د.ل\nشكراً لتعاونكم — أركان المدرسية"
            webbrowser.open(f"https://wa.me/{phone}?text={urllib.parse.quote(msg)}")

        self.btn(form,"تسجيل دفعة",save,C["teal"],140)
        self.btn(form,"💬  إيصال واتساب",send_whatsapp_reminder,"#25D366",180)
        t=self.tree(["ID","رقم الطالب","الاسم","المبلغ","التاريخ"])
        con=connect(); cur=con.cursor()
        cur.execute("""SELECT p.id,p.student_id,s.name,p.amount,p.pay_date
                       FROM payments p JOIN students s ON p.student_id=s.id
                       ORDER BY p.id DESC""")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  التقارير
    # ══════════════════════════════════
    def reports_screen(self):
        self.clear_content()
        self.page_title("التقارير","الطلاب ذوو الرسوم المتأخرة")
        t=self.tree(["الطالب","الفصل","إجمالي الرسوم","المدفوع","المتبقي"])
        con=connect(); cur=con.cursor()
        cur.execute("""SELECT name,grade,total_fees,paid_fees,total_fees-paid_fees
                       FROM students WHERE total_fees-paid_fees>0
                       ORDER BY total_fees-paid_fees DESC""")
        for row in cur.fetchall(): t.insert("","end",values=row)
        con.close()

    # ══════════════════════════════════
    #  النسخ الاحتياطي
    # ══════════════════════════════════
    def backup_screen(self):
        self.clear_content()
        self.page_title("النسخ الاحتياطي","حفظ واستعادة قاعدة البيانات")

        card=ctk.CTkFrame(self.content, fg_color=C["card"], corner_radius=20)
        card.pack(fill="x", padx=28, pady=16)

        ctk.CTkLabel(card, text="💾  إنشاء نسخة احتياطية",
                     font=F["head"], text_color=C["gold"]).pack(anchor="e",padx=24,pady=(18,6))
        ctk.CTkLabel(card, text=f"يتم الحفظ تلقائياً في مجلد: {BACKUP_DIR}/ مع التاريخ والوقت",
                     font=F["sub"], text_color=C["muted"]).pack(anchor="e",padx=24,pady=(0,12))

        def do_backup():
            try:
                dst=backup_db()
                messagebox.showinfo("تم",f"تم إنشاء النسخة الاحتياطية:\n{dst}")
                load_backups()
            except Exception as e: messagebox.showerror("خطأ",str(e))

        def do_restore():
            path=filedialog.askopenfilename(
                title="اختر ملف النسخة الاحتياطية",
                filetypes=[("SQLite DB","*.db")])
            if not path: return
            if not messagebox.askyesno("تأكيد","سيتم استبدال قاعدة البيانات الحالية. متأكد؟"): return
            try:
                restore_db(path)
                messagebox.showinfo("تم","تمت الاستعادة. أعد تشغيل البرنامج.")
            except Exception as e: messagebox.showerror("خطأ",str(e))

        bf=ctk.CTkFrame(card,fg_color="transparent"); bf.pack(anchor="e",padx=24,pady=(0,18))
        ctk.CTkButton(bf, text="💾  إنشاء نسخة الآن", command=do_backup,
            fg_color=C["teal"], hover_color=C["teal2"],
            text_color=C["white"], font=F["btn"],
            height=44, width=200, corner_radius=12).pack(side="right",padx=6)
        ctk.CTkButton(bf, text="📂  استعادة نسخة", command=do_restore,
            fg_color=C["gold"], hover_color=C["gold2"],
            text_color="#060D18", font=F["btn"],
            height=44, width=180, corner_radius=12).pack(side="right",padx=6)

        list_card=ctk.CTkFrame(self.content,fg_color=C["card"],corner_radius=20)
        list_card.pack(fill="both",expand=True,padx=28,pady=8)
        ctk.CTkLabel(list_card,text="النسخ الاحتياطية المحفوظة",
                     font=F["head"],text_color=C["text"]).pack(anchor="e",padx=24,pady=(16,8))

        t=self._styled_tree(list_card,["اسم الملف","الحجم","التاريخ"],height=8)

        def load_backups():
            for i in t.get_children(): t.delete(i)
            if not os.path.exists(BACKUP_DIR): return
            files=sorted(os.listdir(BACKUP_DIR),reverse=True)
            for f in files:
                if f.endswith(".db"):
                    fp=os.path.join(BACKUP_DIR,f)
                    sz=f"{os.path.getsize(fp)//1024} KB"
                    mt=datetime.fromtimestamp(os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M")
                    t.insert("","end",values=(f,sz,mt))

        load_backups()


    # ══════════════════════════════════
    #  سجل الحضور الشهري
    # ══════════════════════════════════
    def monthly_attendance_screen(self):
        self.clear_content()
        self.page_title("سجل الحضور الشهري","ملخص حضور وغياب الطلاب شهرياً")
        form = self.form_frame()
        month_e = self.input(form,"الشهر (YYYY-MM)",160)
        month_e.insert(0, date.today().strftime("%Y-%m"))
        classes = self.get_visible_classes()
        cmap = {f"{r[1]} {r[2]}": r[0] for r in classes}
        cbox = self.combo(form, ["الكل"]+list(cmap.keys()), 220)

        def load():
            for i in t.get_children(): t.delete(i)
            mo = month_e.get().strip()
            con = connect(); cur = con.cursor()
            sel = cbox.get()
            base = f"AND s.class_id={cmap[sel]}" if sel != "الكل" and sel in cmap else ""
            cur.execute(f"""
                SELECT s.name,
                       IFNULL(c.class_name||' '||c.section, s.grade),
                       SUM(CASE WHEN a.status='حاضر' THEN 1 ELSE 0 END),
                       SUM(CASE WHEN a.status='غائب'  THEN 1 ELSE 0 END),
                       SUM(CASE WHEN a.status='متأخر' THEN 1 ELSE 0 END),
                       COUNT(a.id)
                FROM students s
                LEFT JOIN attendance a ON a.person_id=s.id AND a.person_type='طالب'
                    AND a.day LIKE ?
                LEFT JOIN classes c ON s.class_id=c.id
                WHERE 1=1 {base}
                GROUP BY s.id ORDER BY s.name
            """, (mo+"%",))
            for row in cur.fetchall():
                t.insert("","end", values=row)
            con.close()

        self.btn(form,"عرض",load,C["gold"],90)
        t = self.tree(["الطالب","الفصل","حاضر","غائب","متأخر","إجمالي الأيام"])
        load()

    # ══════════════════════════════════
    #  تقرير الدرجات الكامل
    # ══════════════════════════════════
    def full_grades_report(self):
        self.clear_content()
        self.page_title("تقرير الدرجات الكامل","متوسطات وترتيب الطلاب")
        form = self.form_frame()
        classes = self.get_visible_classes()
        cmap = {f"{r[1]} {r[2]}": r[0] for r in classes}
        cbox = self.combo(form, list(cmap.keys()), 260)

        def load():
            for i in t.get_children(): t.delete(i)
            cid = cmap.get(cbox.get())
            if not cid: return
            con = connect(); cur = con.cursor()
            cur.execute("""
                SELECT s.name,
                       ROUND(AVG(g.total_score),1),
                       COUNT(g.id),
                       SUM(CASE WHEN g.grade_text='راسب' THEN 1 ELSE 0 END)
                FROM students s
                LEFT JOIN grades g ON g.student_id=s.id
                WHERE s.class_id=?
                GROUP BY s.id ORDER BY AVG(g.total_score) DESC
            """, (cid,))
            for rank, row in enumerate(cur.fetchall(), 1):
                tag = "fail" if (row[3] or 0) > 0 else "pass"
                t.insert("","end", values=(rank,)+row, tags=(tag,))
            con.close()

        self.btn(form,"عرض",load,C["gold"],90)
        t = self.tree(["الترتيب","الطالب","المتوسط","عدد المواد","عدد الرسوب"])
        load()

    # ══════════════════════════════════
    #  إدارة المستخدمين وتغيير كلمة المرور
    # ══════════════════════════════════
    def users_screen(self):
        self.clear_content()
        self.page_title("إدارة المستخدمين","إضافة وتعديل المستخدمين وتغيير كلمات المرور")

        form = self.form_frame()
        un = self.input(form,"اسم المستخدم",160)
        pw = self.input(form,"كلمة المرور",140)
        roles = list(ROLE_LABELS.keys())
        rbox = self.combo(form, roles, 180)
        eid = {"v": None}

        def clear_f():
            eid["v"] = None
            un.delete(0,"end"); pw.delete(0,"end")
            rbox.set(roles[0])

        def add_user():
            u = un.get().strip(); p = pw.get().strip()
            if not u or not p:
                messagebox.showwarning("تنبيه","اكتب اسم المستخدم وكلمة المرور"); return
            try:
                con = connect(); cur = con.cursor()
                cur.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                            (u, hash_password(p), rbox.get()))
                con.commit(); con.close()
                messagebox.showinfo("تم",f"تمت إضافة المستخدم: {u}")
                clear_f(); load_users()
            except Exception as e:
                messagebox.showerror("خطأ", str(e))

        def load_edit():
            sel = t.focus()
            if not sel: return
            v = t.item(sel,"values")
            eid["v"] = int(v[0])
            un.delete(0,"end"); un.insert(0,v[1])
            pw.delete(0,"end")
            try: rbox.set(v[2])
            except: pass

        def save_edit():
            if not eid["v"]:
                messagebox.showwarning("تنبيه","اختر مستخدماً أولاً"); return
            u = un.get().strip(); p = pw.get().strip()
            if not u:
                messagebox.showwarning("تنبيه","اكتب اسم المستخدم"); return
            con = connect(); cur = con.cursor()
            if p:
                cur.execute("UPDATE users SET username=?,password=?,role=? WHERE id=?",
                            (u, hash_password(p), rbox.get(), eid["v"]))
            else:
                cur.execute("UPDATE users SET username=?,role=? WHERE id=?",
                            (u, rbox.get(), eid["v"]))
            con.commit(); con.close()
            messagebox.showinfo("تم","تم حفظ التعديل")
            clear_f(); load_users()

        def delete_user():
            sel = t.focus()
            if not sel: return
            v = t.item(sel,"values")
            if v[1] == self.current_username:
                messagebox.showerror("خطأ","لا يمكنك حذف حسابك الحالي"); return
            if not messagebox.askyesno("تأكيد",f"حذف المستخدم: {v[1]}؟"): return
            con = connect(); cur = con.cursor()
            cur.execute("DELETE FROM users WHERE id=?",(int(v[0]),))
            con.commit(); con.close()
            load_users()

        # زر تغيير كلمة المرور الشخصية
        def change_my_password():
            win = ctk.CTkToplevel(self)
            win.title("تغيير كلمة المرور"); win.geometry("420x300")
            win.transient(self); win.grab_set()
            win.configure(fg_color=C["bg"])
            ctk.CTkLabel(win, text="تغيير كلمة المرور الخاصة بك",
                         font=F["head"], text_color=C["gold"]).pack(pady=(24,16))
            old_e = ctk.CTkEntry(win, width=340, height=44, placeholder_text="كلمة المرور الحالية",
                                  show="*", justify="center", font=F["entry"],
                                  fg_color=C["card2"], border_color=C["border"],
                                  text_color=C["text"], corner_radius=12)
            old_e.pack(pady=6)
            new_e = ctk.CTkEntry(win, width=340, height=44, placeholder_text="كلمة المرور الجديدة",
                                  show="*", justify="center", font=F["entry"],
                                  fg_color=C["card2"], border_color=C["border"],
                                  text_color=C["text"], corner_radius=12)
            new_e.pack(pady=6)
            def do_change():
                old = old_e.get().strip(); new = new_e.get().strip()
                if not old or not new:
                    messagebox.showwarning("تنبيه","اكتب كلمتَي المرور"); return
                con = connect(); cur = con.cursor()
                cur.execute("SELECT password FROM users WHERE id=?",(self.current_user_id,))
                row = cur.fetchone()
                if not row or not verify_password(old, row[0]):
                    messagebox.showerror("خطأ","كلمة المرور الحالية غير صحيحة"); con.close(); return
                if len(new) < 4:
                    messagebox.showwarning("تنبيه","كلمة المرور الجديدة قصيرة جداً (4 أحرف على الأقل)"); con.close(); return
                cur.execute("UPDATE users SET password=? WHERE id=?",
                            (hash_password(new), self.current_user_id))
                con.commit(); con.close()
                messagebox.showinfo("تم","تم تغيير كلمة المرور بنجاح ✅")
                win.destroy()
            ctk.CTkButton(win, text="تغيير كلمة المرور", width=340, height=44,
                          fg_color=C["teal"], hover_color=C["teal2"],
                          text_color=C["white"], font=F["btn"], corner_radius=12,
                          command=do_change).pack(pady=(14,4))

        acts = ctk.CTkFrame(self.content, fg_color=C["bg"]); acts.pack(fill="x",padx=28,pady=(0,2))
        self.btn(acts,"إضافة مستخدم",add_user,C["teal"],140)
        self.btn(acts,"تعديل",load_edit,"#F59E0B",90)
        self.btn(acts,"حفظ",save_edit,C["teal2"],90)
        self.btn(acts,"حذف",delete_user,C["red"],80)
        self.btn(acts,"تغيير كلمتي",change_my_password,C["gold"],150)
        self.btn(acts,"مسح",clear_f,C["card2"],80)

        t = self.tree(["ID","اسم المستخدم","الصلاحية","الدور"])
        def load_users():
            for i in t.get_children(): t.delete(i)
            con = connect(); cur = con.cursor()
            cur.execute("SELECT id,username,role FROM users ORDER BY id")
            for row in cur.fetchall():
                t.insert("","end",values=(row[0], row[1], row[2], ROLE_LABELS.get(row[2],row[2])))
            con.close()
        load_users()

    # ══════════════════════════════════
    #  رواتب المعلمين
    # ══════════════════════════════════
    def salaries_screen(self):
        self.clear_content()
        self.page_title("رواتب المعلمين","تسجيل وعرض صرف الرواتب الشهرية")

        form = self.form_frame()
        month_e = self.input(form,"الشهر (YYYY-MM)",160)
        month_e.insert(0, date.today().strftime("%Y-%m"))

        def load():
            for i in t.get_children(): t.delete(i)
            mo = month_e.get().strip()
            con = connect(); cur = con.cursor()
            cur.execute("""
                SELECT te.id, te.name, te.salary,
                       IFNULL(sp.paid_amount, 0),
                       IFNULL(te.salary,0) - IFNULL(sp.paid_amount,0)
                FROM teachers te
                LEFT JOIN salary_payments sp
                    ON sp.teacher_id=te.id AND sp.pay_month=?
                ORDER BY te.name
            """, (mo,))
            for row in cur.fetchall():
                tag = "pass" if row[4] <= 0 else "fail"
                t.insert("","end",values=row, tags=(tag,))
            con.close()

        def pay_salary():
            sel = t.focus()
            if not sel:
                messagebox.showwarning("تنبيه","اختر معلماً"); return
            v = t.item(sel,"values")
            tid = int(v[0]); tname = v[1]
            salary = float(v[2] or 0); already = float(v[3] or 0); remaining = float(v[4] or 0)
            if remaining <= 0:
                messagebox.showinfo("معلومة",f"تم صرف راتب {tname} بالكامل هذا الشهر"); return
            mo = month_e.get().strip()
            if not messagebox.askyesno("تأكيد",
                f"صرف راتب: {tname}\nالشهر: {mo}\nالمبلغ: {remaining:.2f} د.ل\nهل تأكيد؟"): return
            con = connect(); cur = con.cursor()
            # safe ALTER for salary_payments table
            cur.execute("""CREATE TABLE IF NOT EXISTS salary_payments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                teacher_id INTEGER NOT NULL,
                pay_month TEXT NOT NULL,
                paid_amount REAL NOT NULL,
                pay_date TEXT NOT NULL,
                note TEXT,
                UNIQUE(teacher_id, pay_month))""")
            try:
                cur.execute("""INSERT INTO salary_payments(teacher_id,pay_month,paid_amount,pay_date,note)
                               VALUES(?,?,?,?,?)""",
                            (tid, mo, salary, str(date.today()), "راتب شهري"))
            except:
                cur.execute("""UPDATE salary_payments SET paid_amount=paid_amount+?, pay_date=?
                               WHERE teacher_id=? AND pay_month=?""",
                            (remaining, str(date.today()), tid, mo))
            con.commit(); con.close()
            show_toast(self, f"✅  تم صرف راتب {tname}: {salary:.2f} د.ل")
            load()

        self.btn(form,"عرض",load,C["gold"],90)
        self.btn(form,"💰  صرف الراتب المحدد",pay_salary,C["teal"],180)

        t = self.tree(["ID","المعلم","الراتب الأساسي","المصروف","المتبقي"])

        # إنشاء جدول salary_payments إذا لم يكن موجوداً
        try:
            con = connect(); cur = con.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS salary_payments(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                teacher_id INTEGER NOT NULL,
                pay_month TEXT NOT NULL,
                paid_amount REAL NOT NULL,
                pay_date TEXT NOT NULL,
                note TEXT,
                UNIQUE(teacher_id, pay_month))""")
            con.commit(); con.close()
        except: pass
        load()

    # ══════════════════════════════════
    #  تصدير Excel / CSV
    # ══════════════════════════════════
    def export_screen(self):
        self.clear_content()
        self.page_title("تصدير البيانات","تصدير الطلاب والدرجات والحضور والرسوم إلى CSV")

        card = ctk.CTkFrame(self.content, fg_color=C["card"], corner_radius=20,
                            border_width=1, border_color=C["border"])
        card.pack(fill="x", padx=28, pady=16)
        ctk.CTkFrame(card, height=4, fg_color=C["gold"]).pack(fill="x")
        ctk.CTkLabel(card, text="اختر نوع البيانات المراد تصديرها",
                     font=F["head"], text_color=C["gold"]).pack(anchor="e",padx=24,pady=(18,10))

        bf = ctk.CTkFrame(card, fg_color="transparent"); bf.pack(anchor="e",padx=24,pady=(0,20))

        def export_csv(query, filename, headers):
            path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV","*.csv"),("كل الملفات","*.*")],
                initialfile=filename)
            if not path: return
            try:
                con = connect(); cur = con.cursor()
                cur.execute(query)
                rows = cur.fetchall(); con.close()
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    w = csv.writer(f)
                    w.writerow(headers)
                    w.writerows(rows)
                messagebox.showinfo("تم",f"تم التصدير إلى:\n{path}\n({len(rows)} سجل)")
                show_toast(self, f"✅  تم التصدير: {len(rows)} سجل")
            except Exception as e:
                messagebox.showerror("خطأ",str(e))

        exports = [
            ("👨‍🎓  تصدير الطلاب",
             "SELECT s.id,s.name,s.grade,s.parent_phone,s.parent_code,s.total_fees,s.paid_fees,s.total_fees-s.paid_fees FROM students s ORDER BY s.name",
             "students.csv",
             ["ID","الاسم","الفصل","هاتف ولي الأمر","كود ولي الأمر","إجمالي الرسوم","المدفوع","المتبقي"]),
            ("📊  تصدير الدرجات",
             """SELECT s.name,c.class_name||' '||c.section,sub.subject_name,
                g.work_score,g.mid_score,g.final_score,g.total_score,g.grade_text,g.exam_date
                FROM grades g JOIN students s ON g.student_id=s.id
                JOIN subjects sub ON g.subject_id=sub.id
                LEFT JOIN classes c ON s.class_id=c.id ORDER BY s.name""",
             "grades.csv",
             ["الطالب","الفصل","المادة","أعمال","نصف","نهائي","المجموع","التقدير","التاريخ"]),
            ("📋  تصدير الحضور",
             """SELECT s.name,IFNULL(c.class_name||' '||c.section,s.grade),a.status,a.day
                FROM attendance a JOIN students s ON a.person_id=s.id
                LEFT JOIN classes c ON s.class_id=c.id
                WHERE a.person_type='طالب' ORDER BY a.day DESC,s.name""",
             "attendance.csv",
             ["الطالب","الفصل","الحالة","التاريخ"]),
            ("💳  تصدير الرسوم",
             """SELECT s.name,s.grade,p.amount,p.pay_date,p.note
                FROM payments p JOIN students s ON p.student_id=s.id ORDER BY p.pay_date DESC""",
             "payments.csv",
             ["الطالب","الفصل","المبلغ","التاريخ","ملاحظة"]),
            ("👨‍🏫  تصدير المعلمين",
             "SELECT id,name,subject,phone,salary FROM teachers ORDER BY name",
             "teachers.csv",
             ["ID","الاسم","المادة","الهاتف","الراتب"]),
            ("⚠️  الرسوم المتأخرة فقط",
             """SELECT s.name,s.grade,s.total_fees,s.paid_fees,s.total_fees-s.paid_fees
                FROM students s WHERE s.total_fees-s.paid_fees>0 ORDER BY s.total_fees-s.paid_fees DESC""",
             "late_fees.csv",
             ["الطالب","الفصل","إجمالي الرسوم","المدفوع","المتبقي"]),
        ]

        for label, query, fname, headers in exports:
            ctk.CTkButton(bf, text=label,
                fg_color=C["card2"], hover_color=C["gold_dim"],
                text_color=C["text"], font=F["btn"],
                border_width=1, border_color=C["gold"],
                height=44, width=210, corner_radius=12,
                command=lambda q=query,fn=fname,h=headers: export_csv(q,fn,h)
            ).pack(side="right",padx=6,pady=4)

        # معلومة
        info = ctk.CTkFrame(self.content, fg_color=C["card"], corner_radius=16)
        info.pack(fill="x", padx=28, pady=8)
        ctk.CTkLabel(info,
            text="💡  ملاحظة: الملفات تُصدَّر بصيغة CSV بترميز UTF-8 مناسب لفتحها في Excel مباشرةً",
            font=F["sub"], text_color=C["muted"]).pack(padx=20,pady=14)

# ══════════════════════════════════════════
if __name__ == "__main__":
    init_db()
    migrate_plain_passwords()
    app = ArkanV30()
    app.mainloop()
